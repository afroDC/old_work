<?php
  /***********************************
    QUERY Configuration options
  ***********************************/

  // default attributes
  $QUERY_DEFAULT_ATTRIBUTES[0] = "cn";
  $QUERY_DEFAULT_ATTRIBUTES[1] = "uid";
  $QUERY_DEFAULT_ATTRIBUTES[2] = "uniqueMember";
  $QUERY_DEFAULT_ATTRIBUTES[3] = "member";
  $QUERY_DEFAULT_ATTRIBUTES[4] = "objectClass";

  // ignore showing attributes
  $QUERY_DISABLE_ATTRIBUTES[0] = "userPassword";

  // Default return attributes. 
  $QUERY_DEFAULT_RETURN_ATTRIBUTES = "uid,cn,sn,givenName";

  // default filter when quering the ldap server
  $QUERY_DEFAULT_FILTER = "(objectclass=person)";

  // default base suffixes. Add hidden suffixes
  $QUERY_DEFAULT_BASESUFFIX[0] = "cn=monitor";
  $QUERY_DEFAULT_BASESUFFIX[1] = "cn=config";

  // limit number of query result
  // you probably want to keep it on a decent level
  $QUERY_LIMITED_TO = 100;
  
  // csv export settings
  $QUERY_CSV_DELIMITER = ",";
  $QUERY_CSV_DELIMITER_VALUE = ";";
?>