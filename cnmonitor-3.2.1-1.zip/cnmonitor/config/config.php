<?php
/***************************************************
* CN=Monitor Configuration
* Use configuration file config.xml
*
* If you don't want to use the default config.xml file
* name and / or location. Set or uncomment the following option:
* $CONFIG["general"]["xmlfile"] = "/etc/cnmonitor.xml";
* Note that this file must be readable by Apache HTTPd.
***************************************************/
$CONFIG["general"]["xml"] = true;
//$CONFIG["general"]["xmlfile"] = "/etc/cnmonitor.xml";
?>
