<?php

  /* 
     Default Acceptable Replication Delay
     Note. You can always configre each replication delay
     in the variable ACCEPTABLE_DELAY by the name "replication:<replicaroot>"
     That is the full name of the replication root in exact case such as:
     replication:OU=People,dc=test,dc=com
  */
  $DEFAULT_ACCEPTABLE_DELAY = 24;
  
  $ACCEPTABLE_DELAY = Array();
  /*
     Acceptable delay. Example below indicates:
     Acceptable delay of one hour for replica root dc=example,dc=com
  */
  // $ACCEPTABLE_DELAY["replication:dc=example,dc=com"] = 1;
?>