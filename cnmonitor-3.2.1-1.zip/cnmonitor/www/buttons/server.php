<?php
  // disable some buttons if operation not supported
  $serverid = getFormValue("serverid");
  $environmentid = getFormValue("environmentid");

  $buttonCacheEnable = false;
  $buttonIndexesEnable = false;
  $buttonReplicationEnable = false;
  // buttons that are by default enabled
  $buttonQueryEnable = true;
  $buttonSchemaEnable = true;
  $buttonCertificateEnable = true;
  $buttonLoadbalancerEnable = true;

  // Show buttons if vendor functions are available for this directory server type
  $vendorFunctionName = vendorMapToFunction($CNMONITOR_VENDOR)."_setReplicationAgreement";
  if(function_exists($vendorFunctionName)) {
    $buttonReplicationEnable = true;
  }
  $vendorFunctionName = vendorMapToFunction($CNMONITOR_VENDOR)."_setIndex";
  if(function_exists($vendorFunctionName)) {
    $buttonIndexesEnable = true;
  }
  $vendorFunctionName = vendorMapToFunction($CNMONITOR_VENDOR)."_setCache";
  if(function_exists($vendorFunctionName)) {
    $buttonCacheEnable = true;
  }

  // check if is functions are disabled
  if(!functionIsEnabled("replication")) {
    $buttonReplicationEnable = false;
  }
  if(!functionIsEnabled("loadbalancer")) {
    $buttonLoadbalancerEnable = false;
  }
  if(!functionIsEnabled("query")) {
    $buttonQueryEnable = false;
  }
  // config
  if(!functionIsEnabled("schema")) {
    $buttonSchemaEnable = false;
  }
  if(!functionIsEnabled("index")) {
    $buttonIndexesEnable = false;
  }
  if(!functionIsEnabled("cache")) {
    $buttonCacheEnable = false;
  }
  if(!functionIsEnabled("certificate")) {
    $buttonCertificateEnable = false;
  }
  if(!functionIsEnabled("configuration")) {
    $buttonSchemaEnable = false;
    $buttonCacheEnable = false;
    $buttonIndexesEnable = false;
    $buttonCertificateEnable = false;
  }
?>
              <input type="button" class="<?php
                if($page == "server.php") {
                  echo "buttonSelected";
                }
                else {
                  echo "button";
                } ?>" value="<?php 
                  echo getLang('button.overview'); ?>" onClick="openPage('server.php', <?php
                  echo getFormValue('environmentid'); ?>,<?php
                  echo getFormValue('serverid'); ?>, 'settab=server_availability')">
              &nbsp;
              <input type="button" class="<?php
                if($page == "servergraph.php") {
                  echo "buttonSelected";
                }
                else {
                  echo "button";
                } ?>" value="<?php
                  echo getLang('button.monitoring'); ?>" onClick="openPage('servergraph.php', <?php
                  echo getFormValue('environmentid'); ?>,<?php
                  echo getFormValue('serverid'); ?>, 'settab=servergraph_monitor&serverlist[]=<?php
                  echo getServerName(getFormValue('serverid'),getFormValue('environmentid')); ?>')">
<?php
    if($buttonReplicationEnable) {
?>
              &nbsp;
              <input type="button" class="<?php
                if($page == "replication.php") {
                  echo "buttonSelected";
                }
                else {
                  echo "button";
                } ?>" value="<?php
                echo getLang('button.server.replication'); ?>" onClick="openPage('replication.php', <?php
                echo getFormValue('environmentid'); ?>,<?php
                echo getFormValue('serverid'); ?>, 'settab=replication_overview')">
<?php
    }
    if($buttonLoadbalancerEnable) {
?>
              &nbsp;
              <input type="button" class="<?php
                if($page == "loadbalancer.php") {
                  echo "buttonSelected";
                }
                else {
                  echo "button";
                } ?>" value="<?php
                echo getLang('button.loadbalancer'); ?>" onClick="openPage('loadbalancer.php', <?php
                echo getFormValue('environmentid'); ?>,<?php
                echo getFormValue('serverid'); ?>, 'settab=loadbalancer_query')">
<?php
    }
    if($buttonQueryEnable) {
?>
              &nbsp;
              <input type="button" class="<?php
                if($page == "query.php") {
                  echo "buttonSelected";
                }
                else {
                  echo "button";
                } ?>" value="<?php
                echo getLang('button.server.query'); ?>" onClick="openPage('query.php', <?php
                echo getFormValue('environmentid'); ?>,<?php
                echo getFormValue('serverid'); ?>, 'settab=query_query')">
<?php
    }
?>
             &nbsp;
              <input type="button" class="<?php
                if($page == "cache.php" || $page == "schema.php" || $page == "indexes.php") {
                  echo "buttonSelected";
                }
                else {
                  echo "button";
                }
                ?>" value="<?php
                echo getLang("button.configuration"); ?>" onClick="showHideElement('configButtonsDiv')">

           <div id="configButtonsDiv">
<?php
    if($buttonCacheEnable) {
?>
              &nbsp;
              <input type="button" class="<?php
                if($page == "cache.php") {
                  echo "buttonSelected";
                }
                else {
                  echo "button";
                } ?>" value="<?php
                echo getLang('button.server.cache'); ?>" onClick="openPage('cache.php', <?php
                echo getFormValue('environmentid'); ?>,<?php
                echo getFormValue('serverid'); ?>, 'settab=cache_result')">             
<?php
    }
    if($buttonIndexesEnable) {
?>
              &nbsp;
              <input type="button" class="<?php
                if($page == "indexes.php") {
                  echo "buttonSelected";
                }
                else {
                  echo "button";
                } ?>" value="<?php
                echo getLang('button.server.indexes'); ?>" onClick="openPage('indexes.php', <?php
                echo getFormValue('environmentid'); ?>,<?php
                echo getFormValue('serverid'); ?>, 'settab=indexes_result')">             
<?php
    }
    if($buttonCertificateEnable) {
?>
              &nbsp;
              <input type="button" class="<?php
                if($page == "certificate.php") {
                  echo "buttonSelected";
                }
                else {
                  echo "button";
                } ?>" value="<?php
                echo getLang('button.certificate'); ?>" onClick="openPage('certificate.php', <?php
                echo getFormValue('environmentid'); ?>,<?php
                echo getFormValue('serverid'); ?>, 'settab=certificate_result')">             
               &nbsp;
<?php
    }
    if($buttonSchemaEnable) {
?>
              <input type="button" class="<?php
                if($page == "schema.php") {
                  echo "buttonSelected";
                }
                else {
                  echo "button";
                } ?>" value="<?php
                echo getLang('button.server.schema'); ?>" onClick="openPage('schema.php', <?php
                echo getFormValue('environmentid'); ?>,<?php
                echo getFormValue('serverid'); ?>, 'settab=schema_result')">             
               &nbsp;
<?php
    }
?>
             </div>
             