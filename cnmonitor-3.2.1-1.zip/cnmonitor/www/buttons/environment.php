<?php
  $serverid = 0;
  $environmentid = getFormValue("environmentid");
  
  // disable some buttons if operation not supported
  $buttonCacheEnable = false;
  $buttonIndexesEnable = false;
  $buttonServersEnable = false;
  $buttonReplicationEnable = false;
  // buttons that are by default enabled
  $buttonQueryEnable = true;
  $buttonSchemaEnable = true;
  $buttonCertificateEnable = true;
  $buttonLoadbalancerEnable = true;
  if(strlen($CNMONITOR_VENDOR) > 0) {
    $buttonServersEnable = true;
  }

  // Show buttons if vendor functions are available for this directory server type
  $vendorFunctionName = vendorMapToFunction($CNMONITOR_VENDOR)."_setReplicationAgreement";
  if(function_exists($vendorFunctionName)) {
    $buttonReplicationEnable = true;
  }
  $vendorFunctionName = vendorMapToFunction($CNMONITOR_VENDOR)."_setIndex";
  if(function_exists($vendorFunctionName)) {
    $buttonIndexesEnable = true;
  }
  $vendorFunctionName = vendorMapToFunction($CNMONITOR_VENDOR)."_setCache";
  if(function_exists($vendorFunctionName)) {
    $buttonCacheEnable = true;
  }
  
  // check if is functions are disabled
  if(!functionIsEnabled("replication")) {
    $buttonReplicationEnable = false;
  }
  if(!functionIsEnabled("loadbalancer")) {
    $buttonLoadbalancerEnable = false;
  }
  if(!functionIsEnabled("query")) {
    $buttonQueryEnable = false;
  }
  // config
  if(!functionIsEnabled("schema")) {
    $buttonSchemaEnable = false;
  }
  if(!functionIsEnabled("index")) {
    $buttonIndexesEnable = false;
  }
  if(!functionIsEnabled("cache")) {
    $buttonCacheEnable = false;
  }
  if(!functionIsEnabled("certificate")) {
    $buttonCertificateEnable = false;
  }
  if(!functionIsEnabled("configuration")) {
    $buttonSchemaEnable = false;
    $buttonCacheEnable = false;
    $buttonIndexesEnable = false;
    $buttonCertificateEnable = false;
  }
  
?>
              <input type="button" class="<?php
                if($page == "environment.php") {
                  echo "buttonSelected";
                }
                else {
                  echo "button";
                } ?>" value="<?php
                echo getLang('button.overview'); ?>" onClick="openPage('environment.php', <?php
                echo getFormValue('environmentid'); ?>,<?php
                echo $serverid; ?>)">
<?php
  if($buttonServersEnable) {
?>
              &nbsp;
              <input type="button" class="<?php
                if($page == "servergraph.php") {
                  echo "buttonSelected";
                }
                else {
                  echo "button";
                } ?>" value="<?php
                echo getLang('button.monitoring'); ?>" onClick="openPage('servergraphenv.php', <?php
                echo getFormValue('environmentid'); ?>,<?php
                echo $serverid; ?>, 'settab=servergraph_monitor')">
<?php
    if($buttonReplicationEnable) {
?>
              &nbsp;
              <input type="button" class="<?php
                if($page == "replication.php") {
                  echo "buttonSelected";
                }
                else {
                  echo "button";
                } ?>" value="<?php
                echo getLang('button.server.replication'); ?>" onClick="openPage('replicationenv.php', <?php
                echo getFormValue('environmentid'); ?>,<?php
                echo $serverid; ?>, 'settab=replication_overview')">
<?php
    }
    if($buttonLoadbalancerEnable) {
?>
              &nbsp;
              <input type="button" class="<?php
                if($page == "loadbalancer.php") {
                  echo "buttonSelected";
                }
                else {
                  echo "button";
                } ?>" value="<?php
                echo getLang('button.loadbalancer'); ?>" onClick="openPage('loadbalancerenv.php', <?php
                echo getFormValue('environmentid'); ?>,<?php
                echo $serverid; ?>, 'settab=loadbalancer_query')">
<?php
    }
    if($buttonQueryEnable) {
?>
              &nbsp;
              <input type="button" class="<?php
                if($page == "query.php") {
                  echo "buttonSelected";
                }
                else {
                  echo "button";
                } ?>" value="<?php
                echo getLang('button.server.query'); ?>" onClick="openPage('queryenv.php', <?php
                echo getFormValue('environmentid'); ?>,<?php
                echo $serverid; ?>, 'settab=query_query')">
<?php
    }
?>
             &nbsp;
              <input type="button" class="<?php
                if($page == "cache.php" || $page == "schema.php" || $page == "indexes.php") {
                  echo "buttonSelected";
                }
                else {
                  echo "button";
                }
                ?>" value="<?php
                echo getLang("button.configuration"); ?>" onClick="showHideElement('configButtonsDiv')">
             <div id="configButtonsDiv">
<?php
    if($buttonCacheEnable) {
?>
              &nbsp;
              <input type="button" class="<?php
                if($page == "cache.php") {
                  echo "buttonSelected";
                }
                else {
                  echo "button";
                } ?>" value="<?php
                echo getLang('button.server.cache'); ?>" onClick="openPage('cacheenv.php', <?php
                echo getFormValue('environmentid'); ?>,<?php
                echo $serverid; ?>, 'settab=cache_result')">             
<?php
    }
    if($buttonIndexesEnable) {
?>
              &nbsp;
              <input type="button" class="<?php
                if($page == "indexes.php") {
                  echo "buttonSelected";
                }
                else {
                  echo "button";
                } ?>" value="<?php
                echo getLang('button.server.indexes'); ?>" onClick="openPage('indexesenv.php', <?php
                echo getFormValue('environmentid'); ?>,<?php
                echo $serverid; ?>, 'settab=indexes_result')">             
<?php
    }
    if($buttonCertificateEnable) {
?>
              &nbsp;
              <input type="button" class="<?php
                if($page == "certificate.php") {
                  echo "buttonSelected";
                }
                else {
                  echo "button";
                } ?>" value="<?php
                echo getLang('button.certificate'); ?>" onClick="openPage('certificateenv.php', <?php
                echo getFormValue('environmentid'); ?>,<?php
                echo $serverid; ?>, 'settab=certificate_result')">             
<?php
    }
    if($buttonSchemaEnable) {
?>
              &nbsp;
              <input type="button" class="<?php
                if($page == "schema.php") {
                  echo "buttonSelected";
                }
                else {
                  echo "button";
                } ?>" value="<?php
                echo getLang('button.server.schema'); ?>" onClick="openPage('schemaenv.php', <?php
                echo getFormValue('environmentid'); ?>,<?php
                echo $serverid; ?>, 'settab=schema_result')">             
<?php
    }
?>
               </div>
<?php
  } // servers enabled
?>
