        <br>
	    <br>
	    <br>
	    </td>
	  </tr>
	  <tr>
	    <td>
	      <br><br><br>
	    </td>
	  </tr>
	  </table>
    </div>
<?php
  $pagetimestop = microtimeFloat();
  $mobileStatus = getConfigValue("mobile");
?>
  <div id="bottom">
  Page Loaded in <?php echo round(($pagetimestop - $pagetimestart), 3); ?> seconds 
  &nbsp;&nbsp;-&nbsp;&nbsp; 
  &#169; 2009 - 2013
  &nbsp;&nbsp;-&nbsp;&nbsp; 
  <a href="http://cnmonitor.sourceforge.net" target="_blank">http://cnmonitor.sourceforge.net</a>
  <br>
  <br>
<?php
  if(!empty($mobileStatus)) {
?>
  <big>
    <a href="index.php?setmobilestatus=on"><?php echo getLang("page.general.viewmobilepage"); ?></a>
  </big>
<?php
  }
?>
</div>

<!-- Authentication Dialog -->
<div id="authenticationDiv">
<?php
  $environmentid = getFormValue("environmentid");
  $serverid = getFormValue("serverid");

  // get first possbile servername
  if(empty($serverid)) {
    if(!empty($environmentid)) {
      $serverAuthTestName = getFirstRespondingServerInEnvironment($environmentid);
    }
    else {
      $serverAuthTestName = getFirstRespondingServerInEnvironment(0);
    }
  }
  else {
    $serverAuthTestName = getFirstRespondingServerInEnvironment($environmentid, $serverid);
  }

?>
  <form method="get" action="index.php">
  <table width="95%" align="center" cellpadding="3" cellspacing="3" style="background:#ffffff;">
  <tr>
    <td colspan="2">
      <table width="100%" border="0" cellpadding="5" cellspacing="1">
      <tr>
        <td width="32">
          <img id="authimagestatus" src="icons/<?php
            if(getConfigValue("dn",$environmentid, $serverid)) {
              echo "secure";
            }
            else {
              echo "unsecure";
            }
          ?>.png" width="24">
        </td>
        <td>
          <big>
            <?php 
              if(getConfigValue("dn",$environmentid, $serverid)) {
                echo getLang("page.general.authenticated");
              }
              else {
                echo getLang("page.general.authenticate");
              }
            ?>
          </big>
        </td>
      </tr>
      </table>
    </td>
  </tr>
  <tr>
    <td colspan="2">
      <b>Distinguished Name (DN) <?php echo getLang("page.general.or")." ".getLang("page.general.userid"); ?>:</b>
    </td>
  </tr>
  <tr>
    <td colspan="2">
      <input type="text" id="authdn" name="authdn" size="45" value="<?php echo $authdn; ?>">
    </td>
  </tr>
  <tr>
    <td colspan="2">
      <b><?php echo getLang("page.authenticate.password"); ?>:</b>
    </td>
  </tr>
  <tr>
    <td colspan="2">
      <input type="password" id="authpassword" name="authpassword" size="25">
    </td>
  </tr>
  <tr>
    <td width="65%">
      <b><?php echo getLang("page.authenticate.authenticatelevel"); ?>:</b>
    </td>
    <td width="35%">
      <b><?php echo getLang("page.authenticate.ssltls"); ?>:</b>
    </td>
  </tr>
  <tr>
    <td width="50%" valign="top">
      <table  border="0" width="100%" cellpadding="3" cellspacing="3">
      <tr>
        <td width="15" valign="top">
<?php  
  // find correct level to configure
  if(isset($environmentid) && !empty($serverid)) {
    // serverlevel
    $authlevel = "server";
  }
  else if(isset($environmentid)) {
    // serverlevel
    $authlevel = "env";
  }
  else {
    // serverlevel
    $authlevel = "all";
  }

      $dnExist = getConfigValue("dn");
      $authimage = "unsecure";
      if(!empty($dnExist)) {
        $authimage = "secure";
      }
      echo "<img src='icons/".$authimage.".png' width='15'>";
?>
        </td>
        <td width="10" valign="top">
          <input type="radio" name="authlevel" value="all"<?php
            if($authlevel == "all") {
              echo " checked";
            }
          ?>>
        </td>
        <td>
          <?php echo getLang("page.authenticate.allservers"); ?>
        </td>
      </tr>
<?php
 if(isset($environmentid)) {
 
?>
      <tr>
        <td width="15" valign="top">
<?php
      $dnExist = getConfigValue("dn", $environmentid);
      $authimage = "unsecure";
      if(!empty($dnExist)) {
        $authimage = "secure";
      }
      echo "<img src='icons/".$authimage.".png' width='15'>";
?>
        </td>
        <td width="10" valign="top">
          <input type="radio" name="authlevel" value="env"<?php
            if($authlevel == "env") {
              echo " checked";
            }
          ?>>
        </td>
        <td>
          <?php echo getLang("page.authenticate.selectedenvironment"); ?><br>
          <?php echo getConfigValue("name", $environmentid, 0); ?><br>
        </td>
      </tr>
<?php
  } // environment id set

  if(isset($environmentid) && !empty($serverid)) {
?>
      <tr>
        <td width="15" valign="top">
<?php
      $dnExist = getConfigValue("dn", $environmentid, $serverid);
      $authimage = "unsecure";
      if(!empty($dnExist)) {
        $authimage = "secure";
      }
      echo "<img src='icons/".$authimage.".png' width='15'>";
?>
        </td>
        <td width="10" valign="top">
          <input type="radio" name="authlevel" value="server"<?php
            if($authlevel == "server") {
              echo " checked";
            }
          ?>>
        </td>
        <td>
          <?php echo getLang("page.authenticate.selectedserver"); ?><br>
          <?php echo getConfigValue("name", $environmentid, $serverid); ?><br>
        </td>
      </tr>
<?php
  }
?>
      </table>
    </td>
<?php
  $securityisset = 0;
  if(getConfigValue("tls", $environmentid, $serverid)) {
    $securityisset = 1;
  }

  if(getConfigValue("scheme", $environmentid, $serverid)) {
    $securityisset = 1;
  }
?>
    <td width="50%" valign="top">
      <input type="radio" value="tls" name="authsecurity"<?php
            if(getConfigValue("tls", $environmentid, $serverid)) {
              echo " checked";
            }
          ?>> <?php echo getLang("page.authenticate.usetls"); ?><br>
      <input type="radio" value="ldaps" name="authsecurity"<?php
            if(getConfigValue("scheme", $environmentid, $serverid)) {
              echo " checked";
            }
          ?>> <?php echo getLang("page.authenticate.useldaps"); ?><br>
      <input type="radio" value="no" name="authsecurity"<?php
            if($securityisset == 0) {
               echo " checked";
            }
          ?>> <?php echo getLang("page.authenticate.nosecurity"); ?><br>
    </td>
  </tr>
  <tr>
    <td colspan="2">
      <input type="button" onClick="showHideElement('authenticationDiv');" value="<?php echo getLang("page.general.closewindow"); ?>">
      &nbsp;&nbsp;&nbsp;
      <input type="button" onClick="testAuthentication(this.form, '<?php echo $serverAuthTestName; ?>', 1)" value="<?php echo getLang("page.general.reset"); ?>">
      &nbsp;&nbsp;&nbsp;
      &nbsp;&nbsp;&nbsp;
      <input type="button" onClick="testAuthentication(this.form, '<?php echo $serverAuthTestName; ?>', 0)" value="<?php echo getLang("page.general.authenticate"); ?>">
    </td>
  </tr>
  </table>
  <br>
  </form>
</div>

<!-- Configuration Dialog -->
<div id="configurationDiv">
  <form method="get" action="index.php">
  <table width="95%" align="center" cellpadding="3" cellspacing="3" style="background:#ffffff;">
  <tr>
    <td colspan="2">
      <table width="100%" border="0" cellpadding="5" cellspacing="1">
      <tr>
        <td width="32">
          <img src='icons/config.png' width='32'>
        </td>
        <td>
          <big>
            <?php echo getLang('page.general.preferences'); ?>
          </big>
        </td>
      </tr>
      </table>
    </td>
  </tr>
  <tr>
    <td colspan="2">
      <b><?php echo getLang('page.general.reloadpage'); ?></b>
    </td>
  </tr>
  <tr>
    <td width="300">
      <?php echo getLang('page.general.reloadpagedescription'); ?>:
    </td>
    <td width="100">
      <select name="reloadpage" id="reloadpage" onChange="reloadPage(this.value, '<?php echo $CNMONITOR_PAGENAME; ?>')"<?php
        if(empty($CNMONITOR_RELOAD_ENABLED)) {
          echo " disabled='disabled'";
        }
      ?>>
        <option value=""><?php echo getLang("page.general.off"); ?></option>
        <option value="3">3</option>
        <option value="5">5</option>
        <option value="10">10</option>
        <option value="30">30</option>
        <option value="60">60</option>
        <option value="600">600</option>
      </select>
    </td>
  </tr>
  <tr>
    <td colspan="2">
      <hr width="100%"/>
    </td>
  </tr>
  <tr>
    <td>
      <b><?php echo getLang('page.general.language'); ?></b>    
    </td>
    <td>
      <?php
        // get list of available languages
        $availableLanguage = getLanguageList();
        $configuredLanguage = getLanguage();
      ?>
      <select name="config_language" onChange="window.location.href='index.php?config_language=' + this.value">
      <?php for($i = 0; $i < count($availableLanguage); $i++) { ?>
        <option value="<?php echo $availableLanguage[$i]; ?>"<?php
          if($configuredLanguage == $availableLanguage[$i]) {
            echo " selected";
          }
        ?>><?php echo $availableLanguage[$i]; ?></option>
      <?php } ?>
      </select>
    </td>
  </tr>
  <tr>
    <td colspan="2">
      <hr width="100%"/>
    </td>
  </tr>
  <tr>
    <td colspan="2">
      <b><?php echo getLang('page.general.cacheconnectivity'); ?></b>
    </td>
  </tr>
<?php
  $cacheEnabled = getConfigValue("cache_connection");
  if(empty($cacheEnabled)) {
    $cacheValue = "enable";
  }
  else {
    $cacheValue = "disable";
  }
?>
  <tr>
    <td width="300">
      <?php echo getLang('page.general.cacheconnectivitydescription'); ?>:<br>
    </td>
    <td width="100">
      <input type="checkbox" onClick="window.location.href='index.php?cache=<?php echo $cacheValue; ?>'"<?php
        if(!empty($cacheEnabled)) {
          echo " checked'";
        } ?>> <?php echo getLang("page.general.enabled"); ?>
    </td>
  </tr>
  <tr>
    <td colspan="2">
      <ul>
        <li><?php echo getLang('page.general.answeringonport'); ?></li>
      </ul>
    </td>
  </tr>
  <tr>
    <td colspan="2">
      <hr width="100%"/>
    </td>
  </tr>
  <tr>
    <td colspan="2">
      <b><?php echo getLang('page.general.cacheclear'); ?></b>
    </td>
  </tr>
  <tr>
    <td width="300">
      <?php echo getLang('page.general.cachecleardescription'); ?>:
    </td>
    <td width="100">
      <input type="button" onClick="window.location.href='index.php?cache=clear'" value="<?php echo getLang('page.general.cacheclear'); ?>">
    </td>
  </tr>
  <tr>
    <td colspan="2">
      <ul>
        <li><?php echo getLang('page.general.preferences'); ?></li>
        <li><?php echo getLang('page.general.schema'); ?></li>
        <li><?php echo getLang('page.general.certificate'); ?></li>
        <li>...</li>
      </ul>
    </td>
  </tr>
  </table>
  </form>
  <br>
</div>

</body>

<script language="javascript">

  /*****
    Pre load a special tab or Services
  **/
  <?php
    // to ensure that we have a tab for important pages:
    $settab = getFormValue('settab');
    if(empty($settab)) {
      $settab = "environments_availability";
      $page = getFormValue("page");
      if(empty($page)) {
        $settab = "environments_availability";
      }
      else if($page == "environment.php") {
        $settab = "environment_availability";
	  }
      else if($page == "server.php") {
        $settab = "server_availability";
      }
    } // if tab empty
  ?>
  var preloadtab = "<?php echo $settab; ?>";
  
  function onPageLoad() {
    if(preloadtab) {
      showTab(preloadtab);
    }
  }

  $(function(){
    $(".ttPlugin").tipTip({defaultPosition: 'top'});
  });

</script>

</html>
