<br>
<?php
  $pagetimestop = microtimeFloat();
?>
<div id="bottom">
  <big>
    <a href="index.php?setmobilestatus=off"><?php echo getLang("page.general.viewnormalpage"); ?></a>
  </big>
<br>
<br>
Page Loaded in <?php echo round(($pagetimestop - $pagetimestart), 3); ?> seconds 
&nbsp;&nbsp;-&nbsp;&nbsp; 
&#169; 2009 - 2013
<br>
<a href="http://cnmonitor.sourceforge.net" target="_blank">http://cnmonitor.sourceforge.net</a>
</div>
<br>
