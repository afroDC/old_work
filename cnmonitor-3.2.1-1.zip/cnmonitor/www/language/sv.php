<?php
  $LANGUAGE["main.selectenvironment"] = "Välj Miljö";

  $LANGUAGE["tab.general.query"] = "Sökning";
  $LANGUAGE["tab.general.result"] = "Resultat";

  $LANGUAGE["tab.welcome"] = "Välkommen";
  $LANGUAGE["tab.environments.environments"] = "Miljöer";
  $LANGUAGE["tab.environments.add"] = "Lägg Till Server";

  $LANGUAGE["tab.environment.availability"] = "Server Tillgänglig";
  $LANGUAGE["tab.environment.statistics"] = "Statistik";
  $LANGUAGE["tab.environment.about"] = "Om";

  $LANGUAGE["tab.server.availability"] = "Databas Tillgänglig";
  $LANGUAGE["tab.server.statistics"] = "Statistik";
  $LANGUAGE["tab.server.certificate"] = "Certifikat";
  $LANGUAGE["tab.server.about"] = "Om";
  $LANGUAGE["tab.cache.general"] = "Cache Storlek";
  $LANGUAGE["tab.indexes.general"] = "Index Sökning";
  $LANGUAGE["tab.certificate.general"] = "Certificates Sökning";

  $LANGUAGE["tab.query.entry"] = "Enskilt Entry";

  $LANGUAGE["tab.schema.query"] = "Schema";

  $LANGUAGE["tab.replication.overview"] = "Replikering Översikt";
  $LANGUAGE["tab.replication.details"] = "Replikering Detaljer";

  $LANGUAGE["tab.servergraph.monitoring"] = "Monitorering";

  $LANGUAGE["tab.loadbalancer.query"] = "Test av Lastbalansering";

  // server cache
  $LANGUAGE["page.cache.queryservers"] = "Hämta Cache Storlek";
  $LANGUAGE["page.cache.graphentry"] = "Poster Cache Graf";
  $LANGUAGE["page.cache.graphdatabase"] = "Databas Cache Graf";  
  $LANGUAGE["page.cache.detailedinfo"] = "Detaljerad Cache Information";
  $LANGUAGE["page.cache.replicaroot"] = "Replika Rot";
  $LANGUAGE["page.cache.maxentriescache"] = "Max Poster i Cache";
  $LANGUAGE["page.cache.freeentrycache"] = "Tillgänglig Entry Cache";
  $LANGUAGE["page.cache.entriesincache"] = "Poster i Cache";
  $LANGUAGE["page.cache.hits"] = "Cache Träffar";
  $LANGUAGE["page.cache.hitratio"] = "Hit Ratio";
  $LANGUAGE["page.cache.current"] = "Nuvarande Cache Storlek";
  $LANGUAGE["page.cache.max"] = "Max Cache Storlek";
  $LANGUAGE["page.cache.free"] = "Tillgänglig Cache";
  $LANGUAGE["page.cache.unablebackend"] = "Kunde ej hämta backend databaser!";
  $LANGUAGE["page.cache.usedcache"] = "Använd";
  $LANGUAGE["page.cache.freecache"] = "Ledig";
  $LANGUAGE["page.indexes.index"] = "Index";
  $LANGUAGE["page.indexes.result"] = "Index Resultat";
  $LANGUAGE["page.certificate.key"] = "Certifikat Nyckel";
  $LANGUAGE["page.certificate.result"] = "Certifikat Resultat";

  // Page
  $LANGUAGE["page.unknown.header"] = "Sidan hittas inte";
  $LANGUAGE["page.unknown.info"] = "Sidan du försöker nå finns inte.";

  $LANGUAGE["page.environments.header"] = "Tillgängliga Miljöer";
  $LANGUAGE["page.environments.answeringonport"] = "Svarar På Port";
  $LANGUAGE["page.environments.answeringonldap"] = "Svarar På LDAP";
  $LANGUAGE["page.environments.serversinenvironment"] = "Servrar i Miljö";
  $LANGUAGE["page.environments.addserver"] = "Lägg till server";
  $LANGUAGE["page.environments.infotemp"] = "Notera: Den här servern läggs endast till temporärt och är endast tillgänglig i din session";
  $LANGUAGE["page.environments.infoperm"] = "För att permanent lägga till servern behöver du lägga till den i config.xml";
  $LANGUAGE["page.environments.sessionenv"] = "Temporär Miljö";

  $LANGUAGE["page.environment.about"] = "Generell Information Om Miljön";
  $LANGUAGE["page.environment.about.loadbalancer"] = "Konfigurerad Lastbalanserare/Kluster address";

  $LANGUAGE["page.replication.server.topology"] = "Server Topologi";
  $LANGUAGE["page.replication.database.topology"] = "Databas Topologi";
  $LANGUAGE["page.replication.database"] = "Databas";
  $LANGUAGE["page.replication.agreements"] = "Kontrakt";
  $LANGUAGE["page.replication.selectedserver"] = "Vald Server";
  $LANGUAGE["page.replication.starttime"] = "Replikering Starttid";
  $LANGUAGE["page.replication.endtime"] = "Replikering Sluttid";
  $LANGUAGE["page.replication.csntime"] = "Server CSN Tid";
  $LANGUAGE["page.replication.schedule"] = "Replikering Schemalagt";
  $LANGUAGE["page.replication.noreplication"] = "Ingen replikering inom konfigurerad accepterad nivå";
  $LANGUAGE["page.replication.nrofchanges"] = "Antal Förändringar";
  $LANGUAGE["page.replication.inprogress"] = "Pågående Replikering";
  $LANGUAGE["page.replication.delays"] = "Replikering tidsverifiering";
  $LANGUAGE["page.replication.delayscsn"] = "Replikeringstid baserat på nuvarande master tid + avslutad replikering i kontrakt.";
  $LANGUAGE["page.replication.delayscurrenttime"] = "Replikeringstid baserat på Change Sequence Number (CSN).";

  $LANGUAGE["page.server.general.serverstatus"] = "Server Status";
  $LANGUAGE["page.server.general.serveroperations"] = "Server Operationer";
  $LANGUAGE["page.server.general.operations"] = "Operationer";
  $LANGUAGE["page.server.general.bindsgraph"] = "Bindningar Graf";
  $LANGUAGE["page.server.general.operationsgraph"] = "Operationer Graf";
  $LANGUAGE["page.server.general.operations.search"] = "Sök";
  $LANGUAGE["page.server.general.operations.add"] = "Add";
  $LANGUAGE["page.server.general.operations.modify"] = "Modify";
  $LANGUAGE["page.server.general.operations.modifyrdn"] = "Modify RDN";
  $LANGUAGE["page.server.general.operations.remove"] = "Remove";
  $LANGUAGE["page.server.general.uptime"] = "Upptid";
  $LANGUAGE["page.server.general.uptime.days"] = "Dagar";
  $LANGUAGE["page.server.general.uptime.hours"] = "Timmar";
  $LANGUAGE["page.server.general.uptime.minutes"] = "Minuter";
  $LANGUAGE["page.server.errormessage"] = "Certifikat Validering Misslyckades med";
  $LANGUAGE["page.server.certificate.errormessage"] = "Hämtning av certifikat misslyckades";
  $LANGUAGE["page.server.certificate.subject"] = "Subjekt";
  $LANGUAGE["page.server.certificate.issuer"] = "Skapat av";
  $LANGUAGE["page.server.certificate.commonname"] = "Namn";
  $LANGUAGE["page.server.certificate.companyname"] = "Företag Name";
  $LANGUAGE["page.server.certificate.organization"] = "Organisation";
  $LANGUAGE["page.server.certificate.location"] = "Lokation";
  $LANGUAGE["page.server.certificate.state"] = "Stat";
  $LANGUAGE["page.server.certificate.country"] = "Land";
  $LANGUAGE["page.server.certificate.date"] = "Certifikat Datum";
  $LANGUAGE["page.server.certificate.validfrom"] = "Giltigt Från";
  $LANGUAGE["page.server.certificate.validto"] = "Giltigt Till";
  $LANGUAGE["page.server.certificate.extensions"] = "Tillägg";
  $LANGUAGE["page.server.certificate.extensions.altname"] = "Alternativt Namn";
  
  $LANGUAGE["page.server.about"] = "Generell Information Om Servern";
  $LANGUAGE["page.server.about.network"] = "Nätverk";
  $LANGUAGE["page.server.about.supportedldapversion"] = "Supporterad LDAP Version";
  $LANGUAGE["page.server.about.supportedldapmechanisms"] = "Supporterade SASL Mekanismer";
  $LANGUAGE["page.server.about.namingcontext"] = "Namn Kontext";
  $LANGUAGE["page.server.about.hostdns"] = "DNS Namn";
  $LANGUAGE["page.server.about.ldapport"] = "LDAP Port";
  $LANGUAGE["page.server.about.secureport"] = "Säker LDAP Port";
  $LANGUAGE["page.server.about.supportedextensions"] = "Supporterade Extensions";
  $LANGUAGE["page.server.about.supportedcontrol"] = "Supporterade Controls";
  $LANGUAGE["page.server.about.supportedfeatures"] = "Supporterade Features";

  $LANGUAGE["page.servergraph.perseconds"] = "Förändringar per Sekund";
  $LANGUAGE["page.servergraph.entriessent"] = "Returnerade Objekt";
  $LANGUAGE["page.servergraph.bytessent"] = "Returnerade Bytes";
  $LANGUAGE["page.servergraph.kbytessent"] = "Returnerade KiloByte";
  $LANGUAGE["page.servergraph.mbytessent"] = "Returnerade MegaBytes";
  $LANGUAGE["page.servergraph.totalconnections"] = "Antal Anslutningar";
  $LANGUAGE["page.servergraph.curconnections"] = "Nuvarande Anslutningar";
  $LANGUAGE["page.servergraph.addoperations"] = "Add Operationer";
  $LANGUAGE["page.servergraph.modoperations"] = "Modify Operationer";
  $LANGUAGE["page.servergraph.modrdnoperations"] = "Modify RDN Operationer";
  $LANGUAGE["page.servergraph.compareoperations"] = "Compare Operationer";
  $LANGUAGE["page.servergraph.removeoperations"] = "Remove Operationer";
  $LANGUAGE["page.servergraph.inoperations"] = "In Operationer";
  $LANGUAGE["page.servergraph.responsetime"] = "Svarstid (ms)";
  $LANGUAGE["page.servergraph.threads"] = "Trådar";
  $LANGUAGE["page.servergraph.anonymousbinds"] = "Anonymous Binds";
  $LANGUAGE["page.servergraph.unauthbinds"] = "Unauthenticated Binds";
  $LANGUAGE["page.servergraph.simplebinds"] = "Simple Binds";
  $LANGUAGE["page.servergraph.strongbinds"] = "Strong Binds";
  $LANGUAGE["page.servergraph.returnederrors"] = "Errors";
  $LANGUAGE["page.servergraph.selectedservers"] = "Inkluderade Servrar";
  $LANGUAGE["page.servergraph.graphtype"] = "Typ av graf";
  $LANGUAGE["page.servergraph.monitortime"] = "Välj Tid";
  $LANGUAGE["page.servergraph.monitortimelive"] = "Live Monitorering";
  $LANGUAGE["page.servergraph.monitortimehistory"] = "Se Historik";
  $LANGUAGE["page.servergraph.graphtypechanges"] = "Antal förändringar";
  $LANGUAGE["page.servergraph.graphtypesecond"] = "Antal förändringar per sekund";
  $LANGUAGE["page.servergraph.save"] = "Uppdatera";
  $LANGUAGE["page.servergraph.viewsevendays"] = "Se Sju Dagar";
  $LANGUAGE["page.servergraph.viewtoday"] = "Se Idag";
  $LANGUAGE["page.servergraph.zone"] = "Zone";
  $LANGUAGE["page.servergraph.tzconfigured"] = "Konfigurerad Tidszon";
  $LANGUAGE["page.servergraph.tzbrowser"] = "Webläsare Tidszon";

  $LANGUAGE["page.schema.objectclasses"] = "Tillgängliga Objektklasser";
  $LANGUAGE["page.schema.attributes"] = "Tillgängliga Attribut";

  // Buttons general
  $LANGUAGE["button.overview"] = "Översikt";
  $LANGUAGE["button.monitoring"] = "Monitorering";
  $LANGUAGE["button.loadbalancer"] = "Lastbalansering";
  $LANGUAGE["button.configuration"] = "Konfiguration";
  $LANGUAGE["button.certificate"] = "Certifikat";

  // Buttons environment

  // Buttons server
  $LANGUAGE["button.server.query"] = "Sökning";
  $LANGUAGE["button.server.schema"] = "Schema";
  $LANGUAGE["button.server.replication"] = "Replikering";
  $LANGUAGE["button.server.cache"] = "Cache";
  $LANGUAGE["button.server.indexes"] = "Index";

  $LANGUAGE["page.query.querylimitation"] = "Resultat Limiterat till ";
  $LANGUAGE["page.query.queryfield"] = "Sök";
  $LANGUAGE["page.query.querybutton"] = "Sök";
  $LANGUAGE["page.query.getentry"] = "Hämta Objekt";
  $LANGUAGE["page.query.selectservers"] = "Välj Servrar";
  $LANGUAGE["page.query.queryfilter"] = "Filter";
  $LANGUAGE["page.query.queryattribute"] = "Attribut";
  $LANGUAGE["page.query.queryvalue"] = "Värde(n)";
  $LANGUAGE["page.query.queryreturn"] = "Returnerande Attribut";
  $LANGUAGE["page.query.queryprotectedattribute"] = "Skyddade Attribut";
  $LANGUAGE["page.query.queryrun"] = "Starta Sökning";
  $LANGUAGE["page.query.nomatchfound"] = "Ingen träff...";
  $LANGUAGE["page.query.basesuffix"] = "Bas";
  $LANGUAGE["page.query.queryservers"] = "Sök mot en eller flera servrar";
  $LANGUAGE["page.query.createdby"] = "Skapad Av";
  $LANGUAGE["page.query.createdtimestamp"] = "Skapad Datum";
  $LANGUAGE["page.query.updatedby"] = "Uppdaterad Av";
  $LANGUAGE["page.query.updatedtimestamp"] = "Uppdaterad Datum";
  $LANGUAGE["page.query.compare"] = "Jämför med server";
  $LANGUAGE["page.query.operationalattributes"] = "Operationella Attribut";
  $LANGUAGE["page.query.createdby"] = "Skapad Av";
  $LANGUAGE["page.query.createtime"] = "Skapad";
  $LANGUAGE["page.query.modifiedby"] = "Modifierad Av";
  $LANGUAGE["page.query.modifiedtime"] = "Modifierad";

  // load balancer
  $LANGUAGE["page.loadbalancer.verifyfor"] = "Verifiera lastbalansering för";
  $LANGUAGE["page.loadbalancer.numberofqueries"] = "Antal Frågor";
  $LANGUAGE["page.loadbalancer.balancertype"] = "Balanserings typ";
  $LANGUAGE["page.loadbalancer.runqueries"] = "Kör %d Frågor";

  // Authenticate
  $LANGUAGE["page.authenticate.allservers"] = "Alla Konfigurerade Servrar";
  $LANGUAGE["page.authenticate.selectedenvironment"] = "Vald Miljö";
  $LANGUAGE["page.authenticate.selectedserver"] = "Vald Server";
  $LANGUAGE["page.authenticate.usetls"] = "Använd TLS";
  $LANGUAGE["page.authenticate.useldaps"] = "Använd LDAPS";
  $LANGUAGE["page.authenticate.nosecurity"] = "Ingen Säkerhet";
  $LANGUAGE["page.authenticate.password"] = "Lösenord";
  $LANGUAGE["page.authenticate.authenticatelevel"] = "Autenticeringsnivå";
  $LANGUAGE["page.authenticate.ssltls"] = "SSL/TLS";

  // General
  $LANGUAGE["page.general.uptime"] = "Upptid";
  $LANGUAGE["page.general.uptime.days"] = "Dag(ar)";
  $LANGUAGE["page.general.uptime.hours"] = "Timmar";
  $LANGUAGE["page.general.uptime.minutes"] = "Minut(er)";

  $LANGUAGE["page.general.messages"] = "Meddelanden";
  $LANGUAGE["page.general.hostip"] = "IP Adress";
  $LANGUAGE["page.general.messagestime"] = "Tid";
  $LANGUAGE["page.general.messagestype"] = "Meddelande Typ";
  $LANGUAGE["page.general.messagesvalue"] = "Värde";
  $LANGUAGE["page.general.operations"] = "Operationer";
  $LANGUAGE["page.general.searchoperations"] = "Sök Operationer";
  $LANGUAGE["page.general.currentconnections"] = "Nuvarande Anslutningar";
  $LANGUAGE["page.general.totalconnections"] = "Totalt Anslutningar";
  $LANGUAGE["page.general.peakconnections"] = "Peak Anslutningar";
  $LANGUAGE["page.general.maxthreads"] = "Max Trådar";
  $LANGUAGE["page.general.updateinterval"] = "Uppdaterings intervall";
  $LANGUAGE["page.general.persecondsincestartup"] = "per s/start";
  $LANGUAGE["page.general.server"] = "Server";
  $LANGUAGE["page.general.certificate"] = "Certifikat";
  $LANGUAGE["page.general.port"] = "LDAP Port";
  $LANGUAGE["page.general.secureport"] = "Säker Port";
  $LANGUAGE["page.general.cachesize"] = "Cache Storlek";
  $LANGUAGE["page.general.replication"] = "Replikering";
  $LANGUAGE["page.general.replicationstatus"] = "Replikering Status";
  $LANGUAGE["page.general.cachesize"] = "Cache Storlek";
  $LANGUAGE["page.general.querytime"] = "Fråga Tid (ms)";
  $LANGUAGE["page.general.schema"] = "Schema";
  $LANGUAGE["page.general.vendor"] = "Leverantör";
  $LANGUAGE["page.general.vendorrecognized"] = "Server Tolkad Som";
  $LANGUAGE["page.general.version"] = "Version";
  $LANGUAGE["page.general.server"] = "Server";
  $LANGUAGE["page.general.dns"] = "DNS";
  $LANGUAGE["page.general.url"] = "URL";
  $LANGUAGE["page.general.description"] = "Beskrivning";
  $LANGUAGE["page.general.weight"] = "Vikt";
  $LANGUAGE["page.general.percent"] = "Procent";
  $LANGUAGE["page.general.both"] = "Båda";
  $LANGUAGE["page.general.run"] = "Kör";
  $LANGUAGE["page.general.message"] = "Meddelande";
  $LANGUAGE["page.general.authenticate"] = "Autenticera";
  $LANGUAGE["page.general.authenticated"] = "Autenticerad";
  $LANGUAGE["page.general.notauthenticated"] = "Inte Autenticerad";
  $LANGUAGE["page.general.closewindow"] = "Stäng Fönster";
  $LANGUAGE["page.general.reset"] = "Reset";
  $LANGUAGE["page.general.update"] = "Uppdatera";
  $LANGUAGE["page.general.trendsdifference"] = "Årlig / Månad Skillnad";
  $LANGUAGE["page.general.detailedinformation"] = "Detaljerad Information";

  $LANGUAGE["page.general.date"] = "Datum";
  $LANGUAGE["page.general.hour"] = "Timme";
  $LANGUAGE["page.general.minute"] = "Minut";
  $LANGUAGE["page.general.second"] = "Sekund";
  $LANGUAGE["page.general.from"] = "Från";
  $LANGUAGE["page.general.to"] = "Till";
  $LANGUAGE["page.general.select"] = "välj";

  $LANGUAGE["page.general.graphtype"] = "Typ av graf";
  $LANGUAGE["page.general.flash"] = "Flash";
  $LANGUAGE["page.general.image"] = "Bild";

  $LANGUAGE["page.general.serverstarted"] = "Server Startad";
  $LANGUAGE["page.general.servernotavailable"] = "Server svarar ej";
  $LANGUAGE["page.general.notansweringonport"] = "Server svarar inte på port";
  $LANGUAGE["page.general.notansweringonldap"] = "Svarar ej på LDAP";
  $LANGUAGE["page.general.ldaponline"] = "LDAP Svar OK";
  $LANGUAGE["page.general.replicationfailure"] = "Replikeringsfel";
  $LANGUAGE["page.general.answeringonport"] = "Server svarar på port";
  $LANGUAGE["page.general.answeringonping"] = "Server svarar på ping";
  $LANGUAGE["page.general.errortip"] = "Error kan indikera att server ej svarar eller server fel.";

  $LANGUAGE["page.general.environmentname"] = "Miljö Namn";
  $LANGUAGE["page.general.viewresult"] = "Resultat Lista";
  $LANGUAGE["page.general.queryconfiguration"] = "Sök Konfiguration";
  $LANGUAGE["page.general.configuration"] = "Konfiguration";
  $LANGUAGE["page.general.preferences"] = "Inställningar";
  $LANGUAGE["page.general.cacheclear"] = "Rensa Cache";
  $LANGUAGE["page.general.cachecleardescription"] = "Rensa alla cachade objeckt och ladda om konfigurationen. Cache inkluderar";
  $LANGUAGE["page.general.reloadpage"] = "Ladda om sida";
  $LANGUAGE["page.general.reloadpagedescription"] = "Ladda om den här sidan i sekunder varje";
  $LANGUAGE["page.general.cacheconnectivity"] = "Cache Kommunikation";
  $LANGUAGE["page.general.cacheconnectivitydescription"] = "Aktivera / Avaktivera cache för den här sessionen";
  $LANGUAGE["page.general.exportcsvfile"] = "Exportera CSV Fil";

  $LANGUAGE["page.general.collectservermessage"] = "Collect Server Message Skript";
  $LANGUAGE["page.general.collectdb"] = "Collect Database Skript";
  $LANGUAGE["page.general.collectsummary"] = "Collect Summary Skript";
  $LANGUAGE["page.general.collectmailreport"] = "Collect Report Skript";

  $LANGUAGE["page.general.na"] = "n/a";
  $LANGUAGE["page.general.yes"] = "Ja";
  $LANGUAGE["page.general.no"] = "Nej";
  $LANGUAGE["page.general.off"] = "Av";
  $LANGUAGE["page.general.or"] = "eller";
  $LANGUAGE["page.general.imagesize"] = "Bild storlek";
  $LANGUAGE["page.general.width"] = "Bredd";
  $LANGUAGE["page.general.height"] = "Höjd";
  $LANGUAGE["page.general.userid"] = "Användar ID";
  $LANGUAGE["page.general.add"] = "Lägg till";
  $LANGUAGE["page.general.unknown"] = "okänd";
  $LANGUAGE["page.general.unlimited"] = "Obegränsad";
  $LANGUAGE["page.general.failed"] = "Misslyckades";
  $LANGUAGE["page.general.notconfigured"] = "Inte Konfigurerat";
  $LANGUAGE["page.general.error"] = "Fel";
  $LANGUAGE["page.general.ok"] = "Ok";
  $LANGUAGE["page.general.max"] = "Max";
  $LANGUAGE["page.general.min"] = "Min";
  $LANGUAGE["page.general.result"] = "Resultat";
  $LANGUAGE["page.general.average"] = "Medel";
  $LANGUAGE["page.general.normal"] = "Normal";
  $LANGUAGE["page.general.high"] = "Hög";
  $LANGUAGE["page.general.warning"] = "Varning";
  $LANGUAGE["page.general.enabled"] = "Aktiverad";
  $LANGUAGE["page.general.cache"] = "Cache";
  $LANGUAGE["page.general.total"] = "Total";
  $LANGUAGE["page.general.language"] = "Språk";
  $LANGUAGE["page.general.communication.alert"] = "Öka uppdateringsintervall vid varning. Verififiera servrar vid fel indikation.";
  $LANGUAGE["page.general.view"] = "Öppna vy";
  $LANGUAGE["page.general.viewnormalpage"] = "Visa Normal Sida";  
  $LANGUAGE["page.general.viewmobilepage"] = "Visa Mobil Sida";  
  $LANGUAGE["page.general.historical"] = "Historik";
  $LANGUAGE["page.general.loading"] = "Sidan Laddas";
  $LANGUAGE["page.general.zoomin"] = "Zooma in x%s för detaljerat resultat";

  // Tool tip language settings
  $LANGUAGE["tooltip.servergraph.servers"] = "Valda servrar att inkludera i monitorering.";
  $LANGUAGE["tooltip.servergraph.time"] = "Välj datum och tid för sparad historik.<br>Live monitorering visar nuvarande last.";
  $LANGUAGE["tooltip.servergraph.operations"] = "Se valda operationer.";
  $LANGUAGE["tooltip.servergraph.type"] = "Visa antal förändringar.<br>Förändringar per sekund visar meddelvärden.";
  $LANGUAGE["tooltip.servergraph.backintime"] = "Gå tillbaka.";
  $LANGUAGE["tooltip.servergraph.forwardintime"] = "Gå fram.";
  $LANGUAGE["tooltip.servergraph.increaseview"] = "Utöka vyn med 50%.";
  $LANGUAGE["tooltip.servergraph.combineresult"] = "Kombinera alla servrar i ett enda resultat.";
  $LANGUAGE["tooltip.servergraph.averageresult"] = "Visa medelvärde.";
  $LANGUAGE["tooltip.servergraph.compareresult"] = "Jämföra grafer med hämtad statistik.<br>Valda servrar visas i ett enda resultat.";
  $LANGUAGE["tooltip.loadbalancer.vendor"] = "Lastbalanserare verifierad som följande leverantör.";
  $LANGUAGE["tooltip.loadbalancer.queries"] = "Antal frågor att ställa mot lastbalanseraren.<br>Frågorna kommer att ställas mot root DN.";
  $LANGUAGE["tooltip.loadbalancer.type"] = "DNS innebär en verifiering av returnerat servernamn.<br>Server verifierar instansnamnet.";
  $LANGUAGE["tooltip.loadbalancer.port"] = "Vilken port frågorna kommer att ställas mot.";
?>