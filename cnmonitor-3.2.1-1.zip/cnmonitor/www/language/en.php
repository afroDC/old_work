<?php
  $LANGUAGE["main.selectenvironment"] = "Select Environment";

  $LANGUAGE["tab.general.query"] = "Query";
  $LANGUAGE["tab.general.result"] = "Result";

  $LANGUAGE["tab.welcome"] = "Welcome";
  $LANGUAGE["tab.environments.environments"] = "Environments";
  $LANGUAGE["tab.environments.add"] = "Add Server";  

  $LANGUAGE["tab.environment.availability"] = "Server Availability";
  $LANGUAGE["tab.environment.statistics"] = "Statistics";
  $LANGUAGE["tab.environment.about"] = "About";

  $LANGUAGE["tab.server.availability"] = "Database Availability";
  $LANGUAGE["tab.server.statistics"] = "Statistics";
  $LANGUAGE["tab.server.certificate"] = "Certificate";
  $LANGUAGE["tab.server.about"] = "About";
  $LANGUAGE["tab.cache.general"] = "Cache Size";
  $LANGUAGE["tab.indexes.general"] = "View Index";
  $LANGUAGE["tab.certificate.general"] = "View Certificates";

  $LANGUAGE["tab.query.entry"] = "Single Entry";

  $LANGUAGE["tab.schema.query"] = "Schema";

  $LANGUAGE["tab.replication.overview"] = "Replication Overview";
  $LANGUAGE["tab.replication.details"] = "Replication Details";

  $LANGUAGE["tab.servergraph.monitoring"] = "Monitoring";

  $LANGUAGE["tab.loadbalancer.query"] = "Query Load Balancer";

  // server cache
  $LANGUAGE["page.cache.queryservers"] = "Query Cache Size";
  $LANGUAGE["page.cache.graphentry"] = "Entry Cache Graph";
  $LANGUAGE["page.cache.graphdatabase"] = "Database Cache Graph";  
  $LANGUAGE["page.cache.detailedinfo"] = "Detailed Cache Information";
  $LANGUAGE["page.cache.replicaroot"] = "Replica Root";
  $LANGUAGE["page.cache.maxentriescache"] = "Max Entries in Cache";
  $LANGUAGE["page.cache.entriesincache"] = "Entries in Cache";
  $LANGUAGE["page.cache.freeentrycache"] = "Free Entry Cache";
  $LANGUAGE["page.cache.hits"] = "Cache Hits";
  $LANGUAGE["page.cache.hitratio"] = "Hitratio";
  $LANGUAGE["page.cache.current"] = "DB Cache Size";
  $LANGUAGE["page.cache.max"] = "Max DB Cache";
  $LANGUAGE["page.cache.free"] = "Free DB Cache";
  $LANGUAGE["page.cache.dnmax"] = "Max DN Cache";
  $LANGUAGE["page.cache.dncurrent"] = "Current DN Cache";
  $LANGUAGE["page.cache.indexmax"] = "Max Index Cache";
  $LANGUAGE["page.cache.indexcurrent"] = "Current Index Cache";
  $LANGUAGE["page.cache.unablebackend"] = "Unable to get backend databases!";
  $LANGUAGE["page.cache.usedcache"] = "Used";
  $LANGUAGE["page.cache.freecache"] = "Free";
  $LANGUAGE["page.indexes.index"] = "Index";
  $LANGUAGE["page.indexes.result"] = "Index Result";
  $LANGUAGE["page.certificate.key"] = "Certificate Key";
  $LANGUAGE["page.certificate.result"] = "Certificate Result";

  // Page
  $LANGUAGE["page.unknown.header"] = "Page not found";
  $LANGUAGE["page.unknown.info"] = "The page you are trying to reach doesn't exist.";
  
  $LANGUAGE["page.environments.header"] = "Available Environments";
  $LANGUAGE["page.environments.answeringonport"] = "Answering On Port";
  $LANGUAGE["page.environments.answeringonldap"] = "Answering On LDAP";
  $LANGUAGE["page.environments.serversinenvironment"] = "Servers In Environment";
  $LANGUAGE["page.environments.addserver"] = "Add new server";
  $LANGUAGE["page.environments.infotemp"] = "Note: This server will only be temporary added during and only visible within your session";
  $LANGUAGE["page.environments.infoperm"] = "To permanently adding a server you need to add it to config.xml";
  $LANGUAGE["page.environments.sessionenv"] = "Session Environment";

  $LANGUAGE["page.environment.about"] = "General Information About Environment";
  $LANGUAGE["page.environment.about.loadbalancer"] = "Configured Loadbalancer/Cluster adress";

  $LANGUAGE["page.replication.server.topology"] = "Server Topology";
  $LANGUAGE["page.replication.database.topology"] = "Database Topology";
  $LANGUAGE["page.replication.agreements"] = "Agreements";
  $LANGUAGE["page.replication.selectedserver"] = "Selected Server";
  $LANGUAGE["page.replication.starttime"] = "Start Replication Time";
  $LANGUAGE["page.replication.endtime"] = "End Replication Time";
  $LANGUAGE["page.replication.csntime"] = "Server Replication Time (CSN)";
  $LANGUAGE["page.replication.schedule"] = "Replication Schedule";
  $LANGUAGE["page.replication.noreplication"] = "No replication within configured acceptable hours";
  $LANGUAGE["page.replication.nrofchanges"] = "Nr Of Changes";
  $LANGUAGE["page.replication.inprogress"] = "In Progress";
  $LANGUAGE["page.replication.delays"] = "Replication Delays";
  $LANGUAGE["page.replication.delayscsn"] = "Replication delays based on current time on server + end time for each agreement.";
  $LANGUAGE["page.replication.delayscurrenttime"] = "Replication delays based on Change Sequence Number (CSN) value.";

  $LANGUAGE["page.server.general.serverstatus"] = "Server Status";
  $LANGUAGE["page.server.general.serveroperations"] = "Server Operations";
  $LANGUAGE["page.server.general.operations"] = "Operations";
  $LANGUAGE["page.server.general.bindsgraph"] = "Binds Graph";
  $LANGUAGE["page.server.general.operationsgraph"] = "Operations Graph";
  $LANGUAGE["page.server.general.operations.search"] = "Search";
  $LANGUAGE["page.server.general.operations.add"] = "Add";
  $LANGUAGE["page.server.general.operations.modify"] = "Modify";
  $LANGUAGE["page.server.general.operations.modifyrdn"] = "Modify RDN";
  $LANGUAGE["page.server.general.operations.remove"] = "Remove";
  $LANGUAGE["page.server.errormessage"] = "Certificate Validation Failed width";
  $LANGUAGE["page.server.certificate.errormessage"] = "Unable to retrieve certificate";
  $LANGUAGE["page.server.certificate.subject"] = "Subject";
  $LANGUAGE["page.server.certificate.issuer"] = "Issuer";
  $LANGUAGE["page.server.certificate.commonname"] = "Common Name";
  $LANGUAGE["page.server.certificate.companyname"] = "Company Name";
  $LANGUAGE["page.server.certificate.organization"] = "Organization";
  $LANGUAGE["page.server.certificate.location"] = "Location";
  $LANGUAGE["page.server.certificate.state"] = "State";
  $LANGUAGE["page.server.certificate.country"] = "Country";
  $LANGUAGE["page.server.certificate.date"] = "Certificate Date";
  $LANGUAGE["page.server.certificate.validfrom"] = "Valid From";
  $LANGUAGE["page.server.certificate.validto"] = "Valid To";
  $LANGUAGE["page.server.certificate.extensions"] = "Extensions";
  $LANGUAGE["page.server.certificate.extensions.altname"] = "Alternative Name";
  
  $LANGUAGE["page.server.about"] = "General Information About Server";
  $LANGUAGE["page.server.about.network"] = "Network";
  $LANGUAGE["page.server.about.namingcontext"] = "Naming Contexts";
  $LANGUAGE["page.server.about.supportedldapversion"] = "Supported LDAP Version";
  $LANGUAGE["page.server.about.supportedldapmechanisms"] = "Supported SASL Mechanisms";
  $LANGUAGE["page.server.about.hostdns"] = "DNS Name";
  $LANGUAGE["page.server.about.ldapport"] = "LDAP Port";
  $LANGUAGE["page.server.about.secureport"] = "Secure LDAP Port";
  $LANGUAGE["page.server.about.supportedextensions"] = "Supported Extensions";
  $LANGUAGE["page.server.about.supportedcontrol"] = "Supported Controls";
  $LANGUAGE["page.server.about.supportedfeatures"] = "Supported Features";
  
  $LANGUAGE["page.servergraph.perseconds"] = "Changes per Second";
  $LANGUAGE["page.servergraph.entriessent"] = "Returned Entries";
  $LANGUAGE["page.servergraph.bytessent"] = "Returned Bytes";
  $LANGUAGE["page.servergraph.kbytessent"] = "Returned KiloBytes";
  $LANGUAGE["page.servergraph.mbytessent"] = "Returned MegaBytes";
  $LANGUAGE["page.servergraph.totalconnections"] = "Total Connections";
  $LANGUAGE["page.servergraph.curconnections"] = "Current Connections";
  $LANGUAGE["page.servergraph.addoperations"] = "Add Operations";
  $LANGUAGE["page.servergraph.modoperations"] = "Modify Operations";
  $LANGUAGE["page.servergraph.modrdnoperations"] = "Modify RDN Operations";
  $LANGUAGE["page.servergraph.compareoperations"] = "Compare Operations";
  $LANGUAGE["page.servergraph.removeoperations"] = "Remove Operations";
  $LANGUAGE["page.servergraph.inoperations"] = "In Operations";
  $LANGUAGE["page.servergraph.responsetime"] = "Response Time (ms)";
  $LANGUAGE["page.servergraph.threads"] = "Threads";
  $LANGUAGE["page.servergraph.anonymousbinds"] = "Anonymous Binds";
  $LANGUAGE["page.servergraph.unauthbinds"] = "Unauthenticated Binds";
  $LANGUAGE["page.servergraph.simplebinds"] = "Simple Binds";
  $LANGUAGE["page.servergraph.strongbinds"] = "Strong Binds";
  $LANGUAGE["page.servergraph.returnederrors"] = "Errors";
  $LANGUAGE["page.servergraph.selectedservers"] = "Selected Servers";
  $LANGUAGE["page.servergraph.monitortime"] = "Choose Time";
  $LANGUAGE["page.servergraph.monitortimelive"] = "Live Monitoring";
  $LANGUAGE["page.servergraph.monitortimehistory"] = "View Historical";
  $LANGUAGE["page.servergraph.graphtype"] = "Type";
  $LANGUAGE["page.servergraph.graphtypechanges"] = "Number of changes";
  $LANGUAGE["page.servergraph.graphtypesecond"] = "Changes per second";
  $LANGUAGE["page.servergraph.save"] = "Update";

  $LANGUAGE["page.schema.objectclasses"] = "Available Objectclasses";
  $LANGUAGE["page.schema.attributes"] = "Available Attributes";

  // Buttons general
  $LANGUAGE["button.overview"] = "Overview";
  $LANGUAGE["button.monitoring"] = "Monitoring";
  $LANGUAGE["button.loadbalancer"] = "Load Balancer";
  $LANGUAGE["button.configuration"] = "Configuration";
  $LANGUAGE["button.certificate"] = "Certificate";

  // Buttons environment

  // Buttons server
  $LANGUAGE["button.server.query"] = "Query";
  $LANGUAGE["button.server.schema"] = "Schema";
  $LANGUAGE["button.server.replication"] = "Replication";
  $LANGUAGE["button.server.cache"] = "Cache";
  $LANGUAGE["button.server.indexes"] = "Indexes";

  $LANGUAGE["page.query.querylimitation"] = "Result Limited to ";
  $LANGUAGE["page.query.queryfield"] = "Search";
  $LANGUAGE["page.query.querybutton"] = "Run Query";
  $LANGUAGE["page.query.getentry"] = "Get Entry";
  $LANGUAGE["page.query.queryattribute"] = "Attribute";
  $LANGUAGE["page.query.queryvalue"] = "Value(s)";
  $LANGUAGE["page.query.queryfilter"] = "Query Filter";
  $LANGUAGE["page.query.queryreturn"] = "Return Attributes";
  $LANGUAGE["page.query.queryprotectedattribute"] = "Protected Attributes";
  $LANGUAGE["page.query.nomatchfound"] = "No Match Found...";
  $LANGUAGE["page.query.basesuffix"] = "Base";
  $LANGUAGE["page.query.queryservers"] = "Query One or Serveral servers";
  $LANGUAGE["page.query.createdby"] = "Created By";
  $LANGUAGE["page.query.createdtimestamp"] = "Created TimeStamp";
  $LANGUAGE["page.query.updatedby"] = "Updated By";
  $LANGUAGE["page.query.updatedtimestamp"] = "Updated TimeStamp";
  $LANGUAGE["page.query.compare"] = "Compare with server";
  $LANGUAGE["page.query.operationalattributes"] = "Operational Attributes";
  $LANGUAGE["page.query.createdby"] = "Created By";
  $LANGUAGE["page.query.createtime"] = "Created";
  $LANGUAGE["page.query.modifiedby"] = "Modified By";
  $LANGUAGE["page.query.modifiedtime"] = "Modified";

  // load balancer
  $LANGUAGE["page.loadbalancer.verifyfor"] = "Verify loadbalancer for";
  $LANGUAGE["page.loadbalancer.numberofqueries"] = "Number Of Queries";
  $LANGUAGE["page.loadbalancer.balancertype"] = "Balancer Type";
  $LANGUAGE["page.loadbalancer.runqueries"] = "Run %d Queries";

  // Authenticate
  $LANGUAGE["page.authenticate.allservers"] = "All Configured Servers";
  $LANGUAGE["page.authenticate.selectedenvironment"] = "Selected Environment";
  $LANGUAGE["page.authenticate.selectedserver"] = "Selected Server";
  $LANGUAGE["page.authenticate.usetls"] = "Use TLS";
  $LANGUAGE["page.authenticate.useldaps"] = "Use LDAPS";
  $LANGUAGE["page.authenticate.nosecurity"] = "No Security";
  $LANGUAGE["page.authenticate.password"] = "Password";
  $LANGUAGE["page.authenticate.authenticatelevel"] = "Authentication Level";
  $LANGUAGE["page.authenticate.ssltls"] = "SSL/TLS";

  // General
  $LANGUAGE["page.general.uptime"] = "Uptime";
  $LANGUAGE["page.general.uptime.days"] = "Day(s)";
  $LANGUAGE["page.general.uptime.hours"] = "Hour(s)";
  $LANGUAGE["page.general.uptime.minutes"] = "Minute(s)";

  $LANGUAGE["page.general.selectservers"] = "Select Servers";
  $LANGUAGE["page.general.hostip"] = "IP Address";
  $LANGUAGE["page.general.queryrun"] = "Run Query";
  $LANGUAGE["page.general.messages"] = "Messages";
  $LANGUAGE["page.general.messagestime"] = "Time";
  $LANGUAGE["page.general.messagestype"] = "Message Type";
  $LANGUAGE["page.general.messagesvalue"] = "Value";
  $LANGUAGE["page.general.operations"] = "Operations";
  $LANGUAGE["page.general.searchoperations"] = "Search Operations";
  $LANGUAGE["page.general.currentconnections"] = "Current Connections";
  $LANGUAGE["page.general.totalconnections"] = "Total Connections";
  $LANGUAGE["page.general.peakconnections"] = "Peak Connections";
  $LANGUAGE["page.general.maxthreads"] = "Max Threads";
  $LANGUAGE["page.general.updateinterval"] = "Update Interval";
  $LANGUAGE["page.general.persecondsincestartup"] = "per s/startup";
  $LANGUAGE["page.general.server"] = "Server";
  $LANGUAGE["page.general.certificate"] = "Certificate";
  $LANGUAGE["page.general.port"] = "LDAP Port";
  $LANGUAGE["page.general.secureport"] = "Secure Port";
  $LANGUAGE["page.general.cachesize"] = "Cache Size";
  $LANGUAGE["page.general.replication"] = "Replication";
  $LANGUAGE["page.general.replicationstatus"] = "Replication Status";
  $LANGUAGE["page.general.cachesize"] = "Cache Size";
  $LANGUAGE["page.general.querytime"] = "Query Time (ms)";
  $LANGUAGE["page.general.schema"] = "Schema";
  $LANGUAGE["page.general.vendor"] = "Vendor";
  $LANGUAGE["page.general.vendorrecognized"] = "Server Recognized As";
  $LANGUAGE["page.general.version"] = "Version";
  $LANGUAGE["page.general.server"] = "Server";
  $LANGUAGE["page.general.dns"] = "DNS";
  $LANGUAGE["page.general.url"] = "URL";
  $LANGUAGE["page.general.description"] = "Description";
  $LANGUAGE["page.general.percent"] = "Percent";
  $LANGUAGE["page.general.weight"] = "Weight";
  $LANGUAGE["page.general.both"] = "Both";
  $LANGUAGE["page.general.run"] = "Run";
  $LANGUAGE["page.general.message"] = "Message";
  $LANGUAGE["page.general.authenticate"] = "Authenticate";
  $LANGUAGE["page.general.authenticated"] = "Authenticated";
  $LANGUAGE["page.general.notauthenticated"] = "Not Authenticated";
  $LANGUAGE["page.general.closewindow"] = "Close Window";
  $LANGUAGE["page.general.reset"] = "Reset";
  $LANGUAGE["page.general.update"] = "Update";
  $LANGUAGE["page.general.trendsdifference"] = "Yearly / Monthly Difference";
  $LANGUAGE["page.general.detailedinformation"] = "Detailed Information";
  $LANGUAGE["page.servergraph.viewsevendays"] = "View Seven Days";
  $LANGUAGE["page.servergraph.viewtoday"] = "View Today";
  $LANGUAGE["page.servergraph.zone"] = "Zone";
  $LANGUAGE["page.servergraph.tzconfigured"] = "Configured Time zone";
  $LANGUAGE["page.servergraph.tzbrowser"] = "Browser Time zone";

  $LANGUAGE["page.general.date"] = "Date";
  $LANGUAGE["page.general.hour"] = "Hour";
  $LANGUAGE["page.general.minute"] = "Minute";
  $LANGUAGE["page.general.second"] = "Second";
  $LANGUAGE["page.general.from"] = "From";
  $LANGUAGE["page.general.to"] = "To";
  $LANGUAGE["page.general.select"] = "select";

  $LANGUAGE["page.general.graphtype"] = "Graph Type";
  $LANGUAGE["page.general.flash"] = "Flash";
  $LANGUAGE["page.general.image"] = "Image";

  $LANGUAGE["page.general.serverstarted"] = "Server Started";
  $LANGUAGE["page.general.servernotavailable"] = "Server not available";
  $LANGUAGE["page.general.notansweringonport"] = "Server is not answering on port";
  $LANGUAGE["page.general.notansweringonldap"] = "Not answering on LDAP";
  $LANGUAGE["page.general.ldaponline"] = "LDAP Online";
  $LANGUAGE["page.general.replicationfailure"] = "Replication Failure";
  $LANGUAGE["page.general.answeringonport"] = "Server is answering on port";
  $LANGUAGE["page.general.answeringonping"] = "Server is answering on ping";
  $LANGUAGE["page.general.errortip"] = "Error could indicate unresponsive server or server failure.";

  $LANGUAGE["page.general.environmentname"] = "Environment Name";
  $LANGUAGE["page.general.viewresult"] = "Result List";
  $LANGUAGE["page.general.queryconfiguration"] = "Query Configuration";
  $LANGUAGE["page.general.configuration"] = "Configuration";
  $LANGUAGE["page.general.preferences"] = "Preferences";
  $LANGUAGE["page.general.cacheclear"] = "Clear Cache";
  $LANGUAGE["page.general.cachecleardescription"] = "Clear all cached objects and reload the configuration. Caches include";
  $LANGUAGE["page.general.reloadpage"] = "Reload Page";
  $LANGUAGE["page.general.reloadpagedescription"] = "Reload this page in seconds every";
  $LANGUAGE["page.general.cacheconnectivity"] = "Cache Connectivity";
  $LANGUAGE["page.general.cacheconnectivitydescription"] = "Enable / Disable caching for this session";
  $LANGUAGE["page.general.exportcsvfile"] = "Export CSV File";

  $LANGUAGE["page.general.collectservermessage"] = "Collect Server Message Script";
  $LANGUAGE["page.general.collectdb"] = "Collect Database Script";
  $LANGUAGE["page.general.collectsummary"] = "Collect Summary Script";
  $LANGUAGE["page.general.collectmailreport"] = "Collect Report Script";

  $LANGUAGE["page.general.database"] = "Database";
  $LANGUAGE["page.general.na"] = "n/a";
  $LANGUAGE["page.general.yes"] = "Yes";
  $LANGUAGE["page.general.no"] = "No";
  $LANGUAGE["page.general.off"] = "Off";
  $LANGUAGE["page.general.or"] = "or";
  $LANGUAGE["page.general.imagesize"] = "Image size";
  $LANGUAGE["page.general.width"] = "Width";
  $LANGUAGE["page.general.height"] = "Height";
  $LANGUAGE["page.general.userid"] = "User ID";
  $LANGUAGE["page.general.add"] = "Add";
  $LANGUAGE["page.general.unknown"] = "unknown";
  $LANGUAGE["page.general.unlimited"] = "Unlimited";
  $LANGUAGE["page.general.failed"] = "Failed";
  $LANGUAGE["page.general.notconfigured"] = "Not Configured";
  $LANGUAGE["page.general.error"] = "Error";
  $LANGUAGE["page.general.ok"] = "Ok";
  $LANGUAGE["page.general.max"] = "Max";
  $LANGUAGE["page.general.min"] = "Min";
  $LANGUAGE["page.general.result"] = "Result";
  $LANGUAGE["page.general.average"] = "Average";
  $LANGUAGE["page.general.normal"] = "Normal";
  $LANGUAGE["page.general.high"] = "High";
  $LANGUAGE["page.general.warning"] = "Warning";
  $LANGUAGE["page.general.enabled"] = "Enabled";
  $LANGUAGE["page.general.cache"] = "Cache";
  $LANGUAGE["page.general.total"] = "Total";
  $LANGUAGE["page.general.language"] = "Language";
  $LANGUAGE["page.general.communication.alert"] = "Increase Update interval on alert. Verify server connectivity on error.";
  $LANGUAGE["page.general.view"] = "View";
  $LANGUAGE["page.general.viewnormalpage"] = "View Normal Page";  
  $LANGUAGE["page.general.viewmobilepage"] = "View Mobile Page";  
  $LANGUAGE["page.general.historical"] = "Historical";
  $LANGUAGE["page.general.loading"] = "Loading Page";
  $LANGUAGE["page.general.zoomin"] = "Zoom in x%s for detailed result";

  // Tool tip language settings
  $LANGUAGE["tooltip.servergraph.servers"] = "Select servers to include in monitoring.";
  $LANGUAGE["tooltip.servergraph.time"] = "Select date and time for collected statistics.<br>Live monitoring will show current load.";
  $LANGUAGE["tooltip.servergraph.operations"] = "Selected operations to view.";
  $LANGUAGE["tooltip.servergraph.type"] = "Show number of changes.<br>Changes per second will show the average load.";
  $LANGUAGE["tooltip.servergraph.backintime"] = "Go Back in time.";
  $LANGUAGE["tooltip.servergraph.forwardintime"] = "Go Forward in time.";
  $LANGUAGE["tooltip.servergraph.increaseview"] = "Increase view by 50%.";
  $LANGUAGE["tooltip.servergraph.combineresult"] = "Combine all servers to one single result.";
  $LANGUAGE["tooltip.servergraph.averageresult"] = "Show Average line.";
  $LANGUAGE["tooltip.servergraph.compareresult"] = "Compare graph with previously collected data.<br>Selected servers will combined to one single result.";
  $LANGUAGE["tooltip.loadbalancer.vendor"] = "Loadbalancer recognized as specified vendor type.";
  $LANGUAGE["tooltip.loadbalancer.queries"] = "Number of queries to send against the loadbalancer.<br>Queries will be sent against root DN.";
  $LANGUAGE["tooltip.loadbalancer.type"] = "DNS will verify the hostname of queried server.<br>Server will verify the replica instance name.";
  $LANGUAGE["tooltip.loadbalancer.port"] = "Which port to sent the queries against.";

?>