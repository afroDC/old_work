<?php
  /*
    Copyright (C) 2009-2011 Andreas Andersson

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
  */

/**
* @package querytime
* @author Andreas Andersson
* @version 1.0
*
*  101112 - Andreas Andersson
*           Created
*/  
class QueryTime {
  
  var $timeconnectionstartstart = 0.00000;
  var $timeconnectionstartend = 0.00000;
  var $timequerystart = 0.00000;
  var $timequeryend = 0.00000;
  var $timeconnectionendstart = 0.00000;
  var $timeconnectionendend = 0.00000;
  var $vendor = "";
  var $vendorname = "";
  var $ldapstatus = false;
  
  function setTimeConnectionStartStart($time) {
    $this->timeconnectionstartstart = $time;
  }

  function setTimeConnectionStartEnd($time) {
    $this->timeconnectionstartend = $time;
  }

  function setTimeQueryStart($time) {
    $this->timequerystart = $time;
  }

  function setTimeQueryEnd($time) {
    $this->timequeryend = $time;
  }

  function setTimeConnectionEndStart($time) {
    $this->timeconnectionendstart = $time;
  }

  function setTimeConnectionEndEnd($time) {
    $this->timeconnectionendend = $time;
  }

  function setVendor($vendor) {
    $this->vendor = $vendor;
  }

  function setVendorName($vendorname) {
    $this->vendorname = $vendorname;
  }

  function setLdapStatus($ldapstatus) {
    $this->ldapstatus = $ldapstatus;
  }
  
  // get functions
  function getLdapStatus() {
    return $this->ldapstatus;
  }

  function getVendor() {
    return $this->vendor;
  }

  function getVendorName() {
    return $this->vendorname;
  }

  function getTimeConnectionStartStart() {
    return $this->timeconnectionstartstart;
  }

  function getTimeConnectionStartEnd() {
    return $this->timeconnectionstartend;
  }

  function getTimeQueryStart() {
    return $this->timequerystart;
  }

  function getTimeQueryEnd() {
    return $this->timequeryend;
  }

  function getTimeConnectionEndStart() {
    return $this->timeconnectionendstart;
  }

  function getTimeConnectionEndEnd() {
    return $this->timeconnectionendend;
  }

}

?>
