<script language="javascript">
  var availableTabs = "cache_result";
</script>
	  <li id="tab_cache_result" class="selectedTab"><a href="#" onClick="showTab('cache_result')"><?php echo getLang('tab.cache.general'); ?></a></li>
	  