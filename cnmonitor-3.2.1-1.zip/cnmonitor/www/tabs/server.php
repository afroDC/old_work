<script language="javascript">
  var availableTabs = "server_availability;server_statistics;server_about";
</script>
	  <li id="tab_server_availability" class="selectedTab"><a href="#" onClick="showTab('server_availability')"><?php echo getLang('tab.server.availability'); ?></a></li><!--
	  --><li id="tab_server_statistics"><a href="#" onClick="showTab('server_statistics')"><?php echo getLang('tab.server.statistics'); ?></a></li><!--
	  --><li id="tab_server_about"><a href="#" onClick="showTab('server_about')"><?php echo getLang('tab.server.about'); ?></a></li>
	  