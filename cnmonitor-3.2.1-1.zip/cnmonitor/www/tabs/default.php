<script language="javascript">
  var availableTabs = "default";
</script>
	  <li id="tab_default" class="selectedTab"><a href="#"><?php echo getLang('tab.welcome'); ?></a></li>
