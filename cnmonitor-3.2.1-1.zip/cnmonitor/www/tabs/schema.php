<script language="javascript">
  var availableTabs = "schema_query;schema_result";
</script>
	  <li id="tab_schema_query" class="selectedTab"><a href="#" onClick="showTab('schema_query')"><?php echo getLang('tab.schema.query'); ?></a></li><!--
	  --><li id="tab_schema_result" class="selectedTab"><a href="#" onClick="showTab('schema_result')"><?php echo getLang('tab.general.result'); ?></a></li>
	  