<script language="javascript">
  var availableTabs = "environment_availability;environment_statistics;environment_about";
</script>
	  <li id="tab_environment_availability" class="selectedTab"><a href="#" onClick="showTab('environment_availability')"><?php echo getLang('tab.environment.availability'); ?></a></li><!--
	  --><li id="tab_environment_statistics"><a href="#" onClick="showTab('environment_statistics')"><?php echo getLang('tab.environment.statistics'); ?></a></li><!--
	  --><li id="tab_environment_about"><a href="#" onClick="showTab('environment_about')"><?php echo getLang('tab.environment.about'); ?></a></li>
