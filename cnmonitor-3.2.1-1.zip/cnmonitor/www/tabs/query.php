<script language="javascript">
  var availableTabs = "query_query;query_result;query_entry";
</script>
	  <li id="tab_query_query" class="selectedTab"><a href="#" onClick="showTab('query_query')"><?php echo getLang('tab.general.query'); ?></a></li><!--
	  --><li id="tab_query_result"><a href="#" onClick="showTab('query_result')"><?php echo getLang('tab.general.result'); ?></a></li><!--
	  --><li id="tab_query_entry"><a href="#" onClick="showTab('query_entry')"><?php echo getLang('tab.query.entry'); ?></a></li>
	  