<?php
  // setup js tabs
  echo "<script language='javascript'>\n";
  echo "var availableTabs = '";
  echo "environments_availability;";
  if(functionIsEnabled("addserver")) { 
    echo "environments_add;";
  }
  echo "environments_messages';\n";
  echo "</script>\n";
  //setup html tabs
  echo "<li id='tab_environments_availability' class='selectedTab'><a href='#' onClick='showTab(\"environments_availability\")'>".getLang("tab.environments.environments")."</a></li><!--\n";
  if(functionIsEnabled("addserver")) {
    echo "--><li id='tab_environments_add'><a href='#' onClick='showTab(\"environments_add\")'>".getLang("tab.environments.add")."</a></li><!--\n";
  }
  echo "--><li id='tab_environments_messages'><a href='#' onClick='showTab(\"environments_messages\")'>".getLang("page.general.messages")."</a></li>\n";
?>