<script language="javascript">
  var availableTabs = "loadbalancer_query";
</script>
	  <li id="tab_loadbalancer_query" class="selectedTab"><a href="#" onClick="showTab('loadbalancer_query')"><?php echo getLang('tab.loadbalancer.query'); ?></a></li>
