<script language="javascript">
  var availableTabs = "certificate_query;certificate_result";
</script>
	  <li id="tab_certificate_query" class="selectedTab"><a href="#" onClick="showTab('certificate_query')"><?php echo getLang('tab.certificate.general'); ?></a></li><!--
	  --><li id="tab_certificate_result" class="selectedTab"><a href="#" onClick="showTab('certificate_result')"><?php echo getLang('tab.general.result'); ?></a></li>	  