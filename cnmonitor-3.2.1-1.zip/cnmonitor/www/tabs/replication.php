<script language="javascript">
  var availableTabs = "replication_overview;replication_details";
</script>
	  <li id="tab_replication_overview" class="selectedTab"><a href="#" onClick="showTab('replication_overview')"><?php echo getLang('tab.replication.overview'); ?></a></li><!--
	  --><li id="tab_replication_details" class="selectedTab"><a href="#" onClick="showTab('replication_details')"><?php echo getLang('tab.replication.details'); ?></a></li>
	  