<script language="javascript">
  var availableTabs = "indexes_query;indexes_result";
</script>
	  <li id="tab_indexes_query" class="selectedTab"><a href="#" onClick="showTab('indexes_query')"><?php echo getLang('tab.indexes.general'); ?></a></li><!--
	  --><li id="tab_indexes_result" class="selectedTab"><a href="#" onClick="showTab('indexes_result')"><?php echo getLang('tab.general.result'); ?></a></li>	  