<script language="javascript">
  var availableTabs = "servergraph_monitor";
</script>
	  <li id="tab_servergraph_monitor" class="selectedTab"><a href="#" onClick="showTab('servergraph_monitor')"><?php echo getLang('tab.servergraph.monitoring'); ?></a></li>