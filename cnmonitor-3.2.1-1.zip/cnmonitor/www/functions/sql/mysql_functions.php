<?php
  /*
    Copyright (C) 2009-2012 Andreas Andersson

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
  */

  /**********************************************************************
  * MySQL Functions
  *
  * Specific MySQL functions
  *
  * Available functionality:
  * (X) dbConnect
  * (X) dbClose
  * (X) dbQuery
  * (X) dbGetNumRows
  * (X) dbGetRow
  * (X) dbFreeResult
  *
  **********************************************************************/

  /**
  * Returns SQL Connect
  */
  function mysql_dbConnect($host, $database, $port = "", $username, $password = "") {
    if(empty($port)) {
      $port = 3306;
    }
    $dbh = @mysql_connect($host.":".$port, 
                          $username, 
                          $password);
    if(empty($dbh)) {
      return "";
    }
    mysql_select_db($database, $dbh);
    return $dbh;
  }

  /**
  * Close database connection
  */
  function mysql_dbClose($dbh) {
    @mysql_close($dbh);
  }

  /**
  * Query database
  */
  function mysql_dbQuery($dbh, $sql) {
    return @mysql_query($sql, $dbh);
  }

  /**
  * Get number of rows
  */
  function mysql_dbGetNumRows($result) {
    return @mysql_num_rows($result);
  }

  /**
  * Get row
  */
  function mysql_dbGetRow($result) {
    return @mysql_fetch_row($result);
  }

  /**
  * Free Result
  */
  function mysql_dbFreeResult($result) {
    @mysql_free_result($result);
  }


?>