<?php
  function getTextForOID($oid) {
    if($oid == "1.3.6.1.4.1.1466.20037") {
      return "Start TLS";
    }
    else if($oid == "2.16.840.1.113730.3.5.7") {
      return "iPlanet Bulk Import Start Extended Operation";
    }
    else if($oid == "2.16.840.1.113730.3.5.8") {
      return "iPlanet Bulk Import Finished Extended Operation";
    }
    else if($oid == "1.3.6.1.4.1.4203.1.11.1") {
      return "Modify Password";
    }
    else if($oid == "2.16.840.1.113730.3.5.3") {
      return "iPlanet Start Replication Request Extended Operation";
    }
    else if($oid == "2.16.840.1.113730.3.5.5") {
      return "iPlanet End Replication Request Extended Operation";
    }
    else if($oid == "2.16.840.1.113730.3.5.6") {
      return "iPlanet Replication Entry Request Extended Operation";
    }
    else if($oid == "2.16.840.1.113730.3.5.4") {
      return "iPlanet Replication Response Extended Operation";
    }
    else if($oid == "1.3.6.1.4.1.4203.1.11.3") {
      return "Who am I?";
    }
    else if($oid == "2.16.840.1.113730.3.4.2") {
      return "ManageDsaIT";
    }
    else if($oid == "2.16.840.1.113730.3.4.3") {
      return "Persistent Search LDAPv3 control";
    }
    else if($oid == "2.16.840.1.113730.3.4.4") {
      return "Netscape Password Expired LDAPv3 control";
    }
    else if($oid == "2.16.840.1.113730.3.4.5") {
      return "Netscape Password Expiring LDAPv3 control";
    }
    else if($oid == "1.2.840.113556.1.4.473") {
      return "Sort Request";
    }
    else if($oid == "1.2.840.113556.1.4.474") {
      return "Sort Response";
    }
    else if($oid == "2.16.840.1.113730.3.4.9") {
      return "VLV Request LDAPv3 control";
    }
    else if($oid == "2.16.840.1.113730.3.4.16") {
      return "Authorization Identity Request Control";
    }
    else if($oid == "2.16.840.1.113730.3.4.15") {
      return "Authorization Identity Response Control";
    }
    else if($oid == "2.16.840.1.113730.3.4.17") {
      return "Real Attributes Only Request Control";
    }    
    else if($oid == "2.16.840.1.113730.3.4.19") {
      return "Chaining loop detection";
    }    
    else if($oid == "1.3.6.1.4.1.42.2.27.9.5.2") {
      return "Get effective rights request control";
    }    
    else if($oid == "1.3.6.1.4.1.42.2.27.9.5.6") {
      return "Directory Server initialization control";
    }
    else if($oid == "1.3.6.1.4.1.42.2.27.9.5.8") {
      return "Account usability control";
    }
    else if($oid == "1.3.6.1.4.1.42.2.27.8.5.1") {
      return "Password policy control";
    }
    else if($oid == "2.16.840.1.113730.3.4.14") {
      return "Specific backend search request control";
    }
    else if($oid == "1.3.6.1.4.1.1466.29539.12") {
      return "Chained request control";
    }
    else if($oid == "2.16.840.1.113730.3.4.12") {
      return "Proxied authorization (version 1) control";
    }
    else if($oid == "2.16.840.1.113730.3.4.18") {
      return "Proxy Authorization Control";
    }
    else if($oid == "2.16.840.1.113730.3.4.13") {
      return "Replication update information control";
    }
    else if($oid == "1.3.6.1.4.1.4203.1.9.1.1") {
      return "LDAP Content Synchronization Control";
    }
    else if($oid == "1.3.6.1.4.1.4203.1.10.1") {
      return "Subentries";
    }
    else if($oid == "1.2.840.113556.1.4.319") {
      return "Paged Results Control";
    }
    else if($oid == "1.2.826.0.1.334810.2.3") {
      return "Values return filter";
    }
    else if($oid == "1.2.826.0.1.3344810.2.3") {
      return "Matched Values Control";
    }
    else if($oid == "1.3.6.1.1.13.2") {
      return "LDAP Post-read Control";
    }
    else if($oid == "1.3.6.1.1.13.1") {
      return "LDAP Pre-read Control";
    }
    else if($oid == "1.3.6.1.1.12") {
      return "Assertion Control";
    }
    else if($oid == "1.3.6.1.1.8") {
      return "Cancel Operation";
    }
    else if($oid == "1.3.6.1.1.14") {
      return "Modify-Increment";
    }
    else if($oid == "1.3.6.1.4.1.1466.101.119.1") {
      return "Dynamic Refresh";
    }
    else if($oid == "1.3.6.1.4.1.4203.1.5.1") {
      return "All Operational Attributes";
    }
    else if($oid == "1.3.6.1.4.1.4203.1.5.2") {
      return "OC AD Lists";
    }
    else if($oid == "1.3.6.1.4.1.4203.1.5.3") {
      return "True/False filters";
    }
    else if($oid == "1.3.6.1.4.1.4203.1.5.1") {
      return "All Operational Attributes";
    }
    else if($oid == "1.3.6.1.4.1.4203.1.5.4") {
      return "Language Tag Options";
    }
    else if($oid == "1.3.6.1.4.1.4203.1.5.5") {
      return "Language Range Options";
    }
    else if($oid == "1.2.840.113556.1.4.805") {
      return "Tree Delete";
    }
    else if($oid == "2.16.840.1.113719.1.27.99.1") {
      return "Superior References";
    }    
    else if($oid == "2.16.840.1.113730.3.5.10") {
      return "Distributed Numeric Assignment Request";
    }    
    else if($oid == "2.16.840.1.113730.3.5.9") {
      return "Digest Authentication Calculation";
    }    
    else if($oid == "1.3.6.1.4.1.4203.666.5.16") {
      return "LDAP Dereference Control";
    }
    else if($oid == "2.16.840.1.113730.3.4.20") {
      return "Use One Backend";
    }    
    else if($oid == "1.3.6.1.4.1.7628.5.101.1") {
      return "LDAP Subentry";
    }    
    else if($oid == "1.3.6.1.4.1.42.2.27.9.6.1" ||
            $oid == "1.3.6.1.4.1.42.2.27.9.6.2" ||
            $oid == "1.3.6.1.4.1.42.2.27.9.6.3" ||
            $oid == "1.3.6.1.4.1.42.2.27.9.6.4" ||
            $oid == "1.3.6.1.4.1.42.2.27.9.6.5" ||
            $oid == "1.3.6.1.4.1.42.2.27.9.6.6" ||
            $oid == "1.3.6.1.4.1.42.2.27.9.6.7" ||
            $oid == "1.3.6.1.4.1.42.2.27.9.6.8" ||
            $oid == "1.3.6.1.4.1.42.2.27.9.6.9" ||
            $oid == "1.3.6.1.4.1.42.2.27.9.6.11" ||
            $oid == "1.3.6.1.4.1.42.2.27.9.6.12" ||
            $oid == "1.3.6.1.4.1.42.2.27.9.6.13" ||
            $oid == "1.3.6.1.4.1.42.2.27.9.6.14" ||
            $oid == "1.3.6.1.4.1.42.2.27.9.6.15" ||
            $oid == "1.3.6.1.4.1.42.2.27.9.6.16" ||
            $oid == "1.3.6.1.4.1.42.2.27.9.6.17" ||
            $oid == "1.3.6.1.4.1.42.2.27.9.6.18" ||
            $oid == "1.3.6.1.4.1.42.2.27.9.6.19" ||
            $oid == "1.3.6.1.4.1.42.2.27.9.6.21" ||
            $oid == "1.3.6.1.4.1.42.2.27.9.6.22" ||
            $oid == "1.3.6.1.4.1.42.2.27.9.6.23" ||
            $oid == "2.16.840.1.113730.3.5.3" ||
            $oid == "2.16.840.1.113730.3.5.4" ||
            $oid == "2.16.840.1.113730.3.5.5" ||
            $oid == "2.16.840.1.113730.3.5.6" ||
            $oid == "2.16.840.1.113730.3.5.7" ||
            $oid == "2.16.840.1.113730.3.5.8") {
      return "Replication protocol private extended operation";
    }
 
    return $oid;
  }
  
  function getLinkForOID($oid) {
    if($oid == "1.3.6.1.4.1.1466.20037") {
      return "http://www.networksorcery.com/enp/rfc/rfc2830.txt";
    }
    if($oid == "1.3.6.1.4.1.4203.1.11.1") {
      return "http://www.networksorcery.com/enp/rfc/rfc3062.txt";
    }
    else if($oid == "1.3.6.1.4.1.4203.1.11.3") {
      return "http://www.networksorcery.com/enp/rfc/rfc4532.txt";
    }
    else if($oid == "2.16.840.1.113730.3.4.2") {
      return "http://www.networksorcery.com/enp/rfc/rfc3296.txt";
    }
    else if($oid == "1.2.840.113556.1.4.473") {
      return "http://www.networksorcery.com/enp/rfc/rfc2891.txt";
    }
    else if($oid == "1.2.840.113556.1.4.474") {
      return "http://www.networksorcery.com/enp/rfc/rfc2891.txt";
    }
    else if($oid == "2.16.840.1.113730.3.4.16") {
      return "http://www.networksorcery.com/enp/rfc/rfc3829.txt";
    }
    else if($oid == "2.16.840.1.113730.3.4.15") {
      return "http://www.networksorcery.com/enp/rfc/rfc3829.txt";
    }
    else if($oid == "2.16.840.1.113730.3.4.18") {
      return "http://www.networksorcery.com/enp/rfc/rfc4370.txt";
    }
    else if($oid == "1.3.6.1.4.1.4203.1.9.1.1") {
      return "http://www.networksorcery.com/enp/rfc/rfc4533.txt";
    }
    else if($oid == "1.3.6.1.4.1.4203.1.10.1") {
      return "http://www.networksorcery.com/enp/rfc/rfc3672.txt";
    }
    else if($oid == "1.2.826.0.1.3344810.2.3") {
      return "http://www.networksorcery.com/enp/rfc/rfc3876.txt";
    }
    else if($oid == "1.3.6.1.1.13.2") {
      return "http://www.networksorcery.com/enp/rfc/rfc4527.txt";
    }
    else if($oid == "1.3.6.1.1.13.1") {
      return "http://www.networksorcery.com/enp/rfc/rfc4527.txt";
    }
    else if($oid == "1.3.6.1.1.12") {
      return "http://www.networksorcery.com/enp/rfc/rfc4528.txt";
    }
    else if($oid == "1.3.6.1.1.8") {
      return "http://www.networksorcery.com/enp/rfc/rfc3909.txt";
    }
    else if($oid == "1.3.6.1.1.14") {
      return "http://www.networksorcery.com/enp/rfc/rfc4525.txt";
    }
    else if($oid == "1.3.6.1.4.1.1466.101.119.1") {
      return "http://www.networksorcery.com/enp/rfc/rfc2589.txt";
    }
    else if($oid == "1.3.6.1.4.1.4203.1.5.1") {
      return "http://www.networksorcery.com/enp/rfc/rfc3673.txt";
    }
    else if($oid == "1.3.6.1.4.1.4203.1.5.2") {
      return "http://www.networksorcery.com/enp/rfc/rfc4529.txt";
    }
    else if($oid == "1.3.6.1.4.1.4203.1.5.3") {
      return "http://www.networksorcery.com/enp/rfc/rfc4526.txt";
    }
    else if($oid == "1.3.6.1.4.1.4203.1.5.4") {
      return "http://www.networksorcery.com/enp/rfc/rfc3866.txt";
    }
    else if($oid == "1.3.6.1.4.1.4203.1.5.5") {
      return "http://www.networksorcery.com/enp/rfc/rfc3866.txt";
    }
    else if($oid == "1.3.6.1.4.1.7628.5.101.1") {
      return "http://www.ietf.org/rfc/rfc3672.txt";
    }
    return "";
  }
?>