<?php
  if(!file_exists("./functions/config_functions.php")) { header("Location: ../index.php"); }
  $querytext = getFormValue("querytext");
?>

<div id="default">

<h2><?php echo getLang('page.general.queryconfiguration'); ?></h2>

<form method="get" name="queryform" action="index.php">
  <input type="hidden" name="page" value="queryconfig.php">
  <input type="hidden" name="settab" value="default">
  <input type="text" name="querytext" value="<?php echo $querytext; ?>">
  <input type="submit" value="Search">
</form>

<?php if (!empty($querytext)) { ?>

<h2><?php echo getLang('page.general.viewresult'); ?></h2>

<table border="0" width="100%" cellpadding="3" cellspacing="3">
<tr>
  <td width="20%" class="tableHeader">
    <?php echo getLang('page.general.environmentname'); ?>
  </td>
  <td width="20%" class="tableHeader">
    <?php echo getLang("page.general.server"); ?>
  </td>
  <td width="30%" class="tableHeader">
    <?php echo getLang("page.general.description"); ?>
  </td>
  <td width="30%" class="tableHeader">
    <?php echo getLang("page.general.url"); ?>
  </td>
</tr>
<?php
  $class = "evenRow";
  for($i = 0; $i < count($CONFIG["env"]); $i++) {
    for($j = 1; $j < count($CONFIG["env"][$i]); $j++) {
      $keys = array_keys($CONFIG["env"][$i][$j]);

      for($k = 0; $k < count($keys); $k++) {
        if($keys[$k] != "password") {
          $currentString = $CONFIG["env"][$i][$j][$keys[$k]];
          if(strripos($currentString, $querytext) !== FALSE) {

            if($class == "oddRow") {
              $class = "evenRow";
            }
            else {
              $class = "oddRow";
            }
?>
<tr class="<?php echo $class; ?>">
  <td>
    <a href="index.php?environmentid=<?php echo $i; ?>&settab=environment_availability"><?php echo $CONFIG["env"][$i][0]["name"]; ?></a>
  </td>
  <td>
    <a href="index.php?environmentid=<?php echo $i; ?>&serverid=<?php echo $j; ?>&settab=server_availability"><?php echo $CONFIG["env"][$i][$j]["name"]; ?></a>
  </td>
  <td>
    <?php 
      echo getConfigValue("description", $i, $j);
    ?>&nbsp;
  </td>
  <td>
    <?php 
      echo getConfigValue("url", $i, $j);
    ?>&nbsp;
  </td>
</tr>
<?php
          }
        } // not password
?>  
<?php
      } // for each config
    } // for each server
  } // for each environment
?>
</table>
<?php } // if query text is present ?>
</div>