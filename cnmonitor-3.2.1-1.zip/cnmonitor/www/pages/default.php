<h3><?php echo getLang('page.unknown.header'); ?></h3>

<?php echo getLang('page.unknown.info'); ?>