<h3>Available Environments</h3>

<?php

?>

<!--
      <table cellpadding="3" cellspacing="3">
      <tr>
        <td colspan="2">
          <big>Database Availabality</big>
        </td>
	  <tr>
	    <td width="200" align="left" valign="top">
          Responds to ping:
	  	</td>
        <td>
          Yes
        </td>
	  </tr>
	  <tr>
	    <td width="200" align="left" valign="top">
          Uptime:
	  	</td>
        <td>
          2 days 4 hours 2 minutes
        </td>
	  </tr>
      <tr>
      </table>
-->