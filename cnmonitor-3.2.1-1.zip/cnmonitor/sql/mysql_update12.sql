-- Upgrade from 0.9.1 to 1.2

USE cnmonitor;

-- Add Column unauthenticated binds
ALTER TABLE operation ADD COLUMN col_mon_unauth_bind bigint(20) default '0';

