-- Upgrade from 0.9 to 0.9.1

USE cnmonitor;

-- Create Server Message Table
CREATE TABLE servermessage (
  col_srvmsg_date timestamp NOT NULL default 0,
  col_srvmsg_host varchar(255) NOT NULL default '',
  col_srvmsg_key varchar(25) NOT NULL default '',
  col_srvmsg_value text default '',
  PRIMARY KEY  (col_srvmsg_date, col_srvmsg_host)
);

-- Drop Old Summary Table
DROP TABLE summary;

-- Create Summary Table
CREATE TABLE summary (
  col_sum_date date NOT NULL default 0,
  col_sum_host varchar(255) NOT NULL default '',
  col_sum_key varchar(25) NOT NULL default '',
  col_sum_value bigint(20) default '0',
  col_sum_updated date NOT NULL default 0,
  PRIMARY KEY  (col_sum_date, col_sum_host, col_sum_key)
);
