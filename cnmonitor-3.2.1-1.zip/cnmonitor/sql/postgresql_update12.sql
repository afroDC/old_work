-- Upgrade from 0.9.1 to 1.2

-- Connect to database
\connect cnmonitor

-- Add column 
ALTER TABLE operation ADD COLUMN col_mon_unauth_bind bigint;

